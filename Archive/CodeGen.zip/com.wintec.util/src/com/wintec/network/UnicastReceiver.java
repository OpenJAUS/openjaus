package com.wintec.network;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;

class UnicastReceiver extends Thread {
	
	private JAUSNetworkConnector jausnet;
	private DatagramSocket ds;
	private boolean running;
	
	UnicastReceiver(JAUSNetworkConnector jausnet) {
		this.jausnet = jausnet;
		ds = jausnet.getDatagramSocket();
		running = false;
	}
	
	public void startRunning() {
		running = true;
		start();
	}
	
	public void stopRunning() {
		running = false;
	}
	
	public void run() {
        byte[] data = new byte[jausnet.getMaxPacketSize()];
        DatagramPacket dpkt = new DatagramPacket(data, data.length);

        while(running && !ds.isClosed()) {
            try {
            	ds.receive(dpkt);
            	jausnet.unicastPacketReceived(dpkt);
            } catch (SocketException se) {
            	System.out.println(se.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
