package com.wintec.network;

import java.net.InetAddress;

public interface JAUSNetworkListener {
    void packetReceived(InetAddress fromAddr, int port, byte[] data);
}
