package com.wintec.network;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.MulticastSocket;
import java.net.SocketException;

class MulticastReceiver extends Thread {
    
	private JAUSNetworkConnector jausnet;
	private MulticastSocket ms;
	private boolean running;
	
	MulticastReceiver(JAUSNetworkConnector jausnet) {
		this.jausnet = jausnet;
		ms = jausnet.getMulticastSocket();
		running = false;
	}
	
	public void startRunning() {
		running = true;
		start();
	}
	
	public void stopRunning() {
		running = false;
	}
	
	public void run() {
        byte[] data = new byte[jausnet.getMaxPacketSize()];
        DatagramPacket dpkt = new DatagramPacket(data, data.length);

        while(running && !ms.isClosed()) {
            try {
            	ms.receive(dpkt);
            	jausnet.multicastPacketReceived(dpkt);
            } catch (SocketException se) {
            	System.out.println(se.getMessage());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
