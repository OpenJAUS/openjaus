package com.wintec.network;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.Vector;

import javax.swing.JOptionPane;

public class JAUSNetworkConnector {

    public static final int	SOCKET_BUFFER_SIZE			= 32768;
    public static final int DEFAULT_PACKET_SIZE			= 4096;
    
	public static final int	JAUS_PORT				= 3794;
	public static final String	DEFAULT_MULTICAST_GROUP		= "224.1.0.1";

	private int					packetSize = DEFAULT_PACKET_SIZE;
	
	private int                 port;
    private NetworkInterface	networkInterface;
	private InetAddress			bindLocalAddress;
	private InetAddress			groupInetAddress;
	
	DatagramSocket		datagramSocket;
	MulticastSocket		multicastSocket;
    MulticastReceiver   multicastReceiver;
    UnicastReceiver     unicastReceiver;

    Vector<JAUSNetworkListener> multicastListenerList = new Vector<JAUSNetworkListener>();
    Vector<JAUSNetworkListener> unicastListenerList = new Vector<JAUSNetworkListener>();

    public JAUSNetworkConnector() {
    }
    
    public String configJAUSNetwork(String nifString) {
    	return configNetwork(nifString, JAUS_PORT,DEFAULT_MULTICAST_GROUP);
    }
    
    public String configNetwork(String nifString, int port, String multicastGroupAddress) {
    	try {
			cleanupNetworkSettings();
			
			// getting network interface object
			this.port = port;
            networkInterface = NetworkInterface.getByName(nifString);
			if (networkInterface != null) {
				Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();
				while (!(bindLocalAddress instanceof Inet4Address) && addresses.hasMoreElements()) {
					bindLocalAddress = addresses.nextElement();
				}
				if (!(bindLocalAddress instanceof Inet4Address)) {
					JOptionPane.showMessageDialog(null, "Can't find IPv4 address for "+networkInterface.getName());
				}
			} else {	
				StringBuffer errorMessage = new StringBuffer();
				errorMessage.append("Network interface " + nifString + " is not available.\n");
				errorMessage.append("Available network interfaces are followings.\n");
				Enumeration<NetworkInterface> nifs = NetworkInterface.getNetworkInterfaces();
				while (nifs.hasMoreElements()) {
					NetworkInterface ni = nifs.nextElement();
					errorMessage.append(ni.getName() + " - " + ni.getDisplayName()+"\n");
				}
				System.out.print(errorMessage.toString());
				JOptionPane.showMessageDialog(null, errorMessage.toString());
				System.exit(1);
			}

			// creating unicast sockets
			InetSocketAddress isaddr = new InetSocketAddress(bindLocalAddress, port);
			datagramSocket = new DatagramSocket(isaddr);
			datagramSocket.setReuseAddress(true);
			datagramSocket.setReceiveBufferSize(SOCKET_BUFFER_SIZE);
            unicastReceiver = new UnicastReceiver(this);

			if (multicastGroupAddress!=null) {
				// creating multicast socket
				groupInetAddress = InetAddress.getByName(multicastGroupAddress);
	            multicastSocket = new MulticastSocket(port);
				multicastSocket.setNetworkInterface(networkInterface);
				multicastSocket.joinGroup(groupInetAddress);
				multicastSocket.setLoopbackMode(true);
	            multicastReceiver = new MulticastReceiver(this);
			}
				
    	} catch (java.net.BindException be) {
    		JOptionPane.showMessageDialog(null, "Cannot bind " + bindLocalAddress + " ["+networkInterface.getDisplayName()+" - "+networkInterface.getName()+"].\nAddress already in use.");
    		System.exit(1);
    	} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		return networkStatus();
    }

    public void startMulticastReceiver() {
    	multicastReceiver.startRunning();
    }
    
    public void startUnicastReceiver() {
    	unicastReceiver.startRunning();
    }

    public void stopMulticastReceiver() {
    	multicastReceiver.stopRunning();
    }
    
    public void stopUnicastReceiver() {
    	unicastReceiver.stopRunning();
    }

    public void multicastPacketReceived(DatagramPacket dpkt) {
        byte[] data = new byte[dpkt.getLength()];
        System.arraycopy(dpkt.getData(),0, data, 0, dpkt.getLength());
		for(JAUSNetworkListener nl:multicastListenerList) {
            nl.packetReceived(dpkt.getAddress(), dpkt.getPort(), data);
        }
	}
    
	public void unicastPacketReceived(DatagramPacket dpkt) {
        byte[] data = new byte[dpkt.getLength()];
        System.arraycopy(dpkt.getData(),0, data, 0, dpkt.getLength());
        for(JAUSNetworkListener nl:unicastListenerList) {
            nl.packetReceived(dpkt.getAddress(), dpkt.getPort(), data);
        }
	}

	public int getPort() {
		return port;
	}

	public InetAddress getGroupInetAddress() {
		return groupInetAddress;
	}

	public InetAddress getBindLocalAddress() {
		return bindLocalAddress;
	}
	
	public void finalize() throws Throwable {
		cleanupNetworkSettings();
		super.finalize();
	}

	private void cleanupNetworkSettings() {
		try {
			if (multicastSocket!=null) {
				multicastReceiver.stopRunning();
				multicastSocket.leaveGroup(groupInetAddress);
				multicastSocket.close();
			}
			if (datagramSocket!=null && datagramSocket.isClosed()) {
				unicastReceiver.stopRunning();
				datagramSocket.close();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public NetworkInterface getNetworkInterface() {
		return networkInterface;
	}

	public DatagramSocket getDatagramSocket() {
		return datagramSocket;
	}

	public MulticastSocket getMulticastSocket() {
		return multicastSocket;
	}

	public String networkStatus() {
		try {
			StringBuffer status = new StringBuffer();
			// network interface name
			status.append("Using network interface " + networkInterface.getName() + " - " + networkInterface.getDisplayName() + ".\n");

			// IP address
			if (bindLocalAddress != null) {
				status.append("Local IP address is " + bindLocalAddress.getHostAddress()+"\n");
			} else {
				status.append("Local IP address is undetermined.\n");
			}

			// port number
			status.append("Local port number is " + datagramSocket.getLocalPort()+"\n");

			// socket buffer size
			status.append("Socket buffer size is " + datagramSocket.getReceiveBufferSize() + ".\n");

			if (multicastSocket!=null && !multicastSocket.isClosed()) {
				// multicast socket loopback status
				if (multicastSocket.getLoopbackMode()) {
					status.append("Multicast socket loopback off.\n");
				} else {
					status.append("Multicast socket loopback on.\n");
				}
			}
			return status.toString();
		} catch (SocketException e) {
			return e.getMessage();
		}
	}

	public void broadcast(byte[] message) {
		if (multicastSocket!=null) {
			DatagramPacket dpkt = new DatagramPacket(message, message.length, groupInetAddress, port);
	        try {
	            multicastSocket.send(dpkt);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		} else {
			System.out.println("Multicast socket is not avaialble.");
		}
    }

    public void send(InetAddress address, int port, byte[] message) {
        DatagramPacket dpkt = new DatagramPacket(message, message.length, address, port);
        try {
            datagramSocket.send(dpkt);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void addUnicastListener(JAUSNetworkListener networkListenter) {
        unicastListenerList.add(networkListenter);
    }

    public void addMulticastListener(JAUSNetworkListener networkListenter) {
        multicastListenerList.add(networkListenter);
    }

    public void setMaxPacketSize(int size) {
    	packetSize = size;
    }
    
    public int getMaxPacketSize() {
    	return packetSize;
    }
}
