/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.util;

import java.io.*;

public class TextFileHandler {

    static public String getContents(File file) throws Exception {
        StringBuffer contents = new StringBuffer();
        BufferedReader input = new BufferedReader(new FileReader(file));
        String line;
        while ((line = input.readLine()) != null) {
            contents.append(line);
            contents.append(System.getProperty("line.separator"));
        }
        input.close();
        return contents.toString();
    }

    static public void setContentsAndWrite(File file, String contents) throws Exception {
        if (!file.exists()) {
            file.createNewFile();
        }
        if (file.isFile() && file.canWrite()) {
            Writer output = new BufferedWriter(new FileWriter(file));
            output.write(contents);
            output.close();
        } else {
            throw new Exception("Problem writing a file: " + file);
        }
    }
}