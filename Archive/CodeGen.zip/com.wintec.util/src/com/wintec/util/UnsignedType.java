package com.wintec.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class UnsignedType {

    public static short unsignedValueOf(byte b) {
        return ((ByteBuffer)ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).put(b).rewind()).getShort();
    }

    public static int unsignedValueOf(short s) {
        return ((ByteBuffer)ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putShort(s).rewind()).getInt();
    }

    public static long unsignedValueOf(int i) {
        return ((ByteBuffer)ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putInt(i).rewind()).getLong();
    }

    public static byte signedByteValueOfUnsignedShort(short unsignedValue) {
        if (unsignedValue<0) return 0;
        return ((ByteBuffer)ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(unsignedValue).rewind()).get();
    }

    public static short signedShortValueOfUnsignedInt(int unsignedValue) {
        if (unsignedValue<0) return 0;
        return ((ByteBuffer)ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(unsignedValue).rewind()).getShort();
    }

    public static int signedIntValueOfUnsignedLong(long unsignedValue) {
        if (unsignedValue<0) return 0;
        return ((ByteBuffer)ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(unsignedValue).rewind()).getInt();
    }
}
