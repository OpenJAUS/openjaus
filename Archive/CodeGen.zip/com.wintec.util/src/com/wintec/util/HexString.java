/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
 *********************************************************************************/
package com.wintec.util;

import java.nio.ByteBuffer;

/**
 * The <i>HexString</i> class provides simple conversion methods from byte and byte array to a hexadecimal string.
 */
public class HexString {
	private HexString() {
	}

	private static char toHexChar(int i) {
		return ((0 <= i) && (i <= 9)) ? (char) ('0' + i) : (char) ('A' + (i - 10));
	}

	/**
	 * Returns hexadecimal string representation of the given byte array. The individual byte is separated by the given
	 * delimiter.
	 * 
	 * @param data
	 *            byte array
	 * @param delimiter
	 *            delimiter string
	 * @return hexadecimal string
	 */
	public static String bytesToHexString(byte[] data, String delimiter) {
		StringBuffer buf = new StringBuffer();
		for (byte aData : data) {
			buf.append(byteToHex(aData)).append(delimiter);
		}
		return (buf.toString());
	}

	/**
	 * Returns hexadecimal string representation of the given byte array and length. The individual byte is separated by
	 * the given delimiter.
	 * 
	 * @param data
	 *            byte array
	 * @param length
	 *            length of the array
	 * @param delimiter
	 *            delimiter string
	 * @return hexadecimal string
	 */
	public static String bytesToHexString(byte[] data, int length, String delimiter) {
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < length; i++) {
			buf.append(byteToHex(data[i])).append(delimiter);
		}
		return (buf.toString());
	}

	/**
	 * Returns hexadecimal string of given byte
	 * 
	 * @param data
	 *            byte value
	 * @return hexadecimal string
	 */
	public static String byteToHex(byte data) {
		StringBuffer buf = new StringBuffer();
		buf.append(toHexChar((data >>> 4) & 0x0F));
		buf.append(toHexChar(data & 0x0F));
		return buf.toString();
	}

	/**
	 * Returns hexadecimal string of given integer
	 * 
	 * @param value
	 *            int value
	 * @return hexadecimal string
	 */
	public static String intToHex(int value) {
		return bytesToHexString(ByteBuffer.allocate(4).putInt(value).array(), "");
	}

	/**
	 * Returns hexadecimal string of given short integer
	 * 
	 * @param value
	 *            short integer value
	 * @return hexadecimal string
	 */
	public static String shortToHex(short value) {
		return bytesToHexString(ByteBuffer.allocate(2).putShort(value).array(), "");
	}

	/**
	 * Returns hexadecimal string of given long integer
	 * 
	 * @param value
	 *            long integer value
	 * @return hexadecimal string
	 */
	public static String longToHex(long value) {
		return bytesToHexString(ByteBuffer.allocate(8).putLong(value).array(), "");
	}
}
