package com.wintec.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class BitBuffer {

    private ByteBuffer buffer;

    public static BitBuffer allocate(int sizeInBytes) {
    	return new BitBuffer(sizeInBytes);
    }
    
    public static BitBuffer wrap(byte[] ba) {
    	return new BitBuffer(ba);
    }

    public static BitBuffer setByte(byte b) {
    	return new BitBuffer(1,b);
    }
    
    public static BitBuffer setShort(short s) {
    	return new BitBuffer(2,s);
    }
    
    public static BitBuffer setInt(int i) {
    	return new BitBuffer(4,i);
    }
    
    public static BitBuffer setLong(long l) {
    	return new BitBuffer(8,l);
    }
    
    private BitBuffer(int sizeInBytes) {
    	buffer = ByteBuffer.allocate(sizeInBytes).order(ByteOrder.LITTLE_ENDIAN);
    }
    
    private BitBuffer(int sizeInBytes, byte b) {
    	this(sizeInBytes);
    	buffer.put(b);
    }
    
    private BitBuffer(int sizeInBytes, short s) {
    	this(sizeInBytes);
    	buffer.putShort(s);
    }
    
    private BitBuffer(int sizeInBytes, int i) {
    	this(sizeInBytes);
    	buffer.putInt(i);
    }
    
    private BitBuffer(int sizeInBytes, long l) {
    	this(sizeInBytes);
    	buffer.putLong(l);
    }
    
    private BitBuffer(byte[] ba) {
    	buffer = ByteBuffer.wrap(ba).order(ByteOrder.LITTLE_ENDIAN);
    }
    
    public byte[] byteArray() {
        return buffer.array();
    }

    public byte byteValue() {
    	buffer.rewind();
    	return buffer.get();
    }

    public short shortValue() {
    	buffer.rewind();
        return buffer.getShort();
    }

    public int intValue() {
    	buffer.rewind();
    	return buffer.getInt();
    }

    public long longValue() {
    	buffer.rewind();
        return buffer.getLong();
    }

    public void setBit(int bitIndex) {
        byte[] value = buffer.array();
    	if (bitIndex >= 0 && bitIndex < value.length * 8) {
            int i = bitIndex / 8;
            int j = bitIndex % 8;
            value[i] = (byte)(value[i] | (Integer.MIN_VALUE >>> (31 - j)));
        } else {
            throw new ArrayIndexOutOfBoundsException("Bit index out of bounds (max size is " + (value.length * 8-1) + ") : " + bitIndex);
        }
    }

    public void clearBit(int bitIndex) {
        byte[] value = buffer.array();
        if (bitIndex >= 0 && bitIndex < value.length * 8) {
            int i = bitIndex / 8;
            int j = bitIndex % 8;
            value[i] = (byte)(value[i] & (~(Integer.MIN_VALUE >>> (31 - j))));
        } else {
            throw new ArrayIndexOutOfBoundsException("Bit index out of bounds (max index is " + (value.length * 8 - 1) + ") : " + bitIndex);
        }
    }

    public boolean getBit(int bitIndex) {
        byte[] value = buffer.array();
        if (bitIndex >= 0 && bitIndex < value.length * 8) {
            int i = bitIndex / 8;
            int j = bitIndex % 8;
            return ((value[i] & (Integer.MIN_VALUE >>> (31 - j))) != 0);
        }
		throw new ArrayIndexOutOfBoundsException("Bit index out of bounds (max size is " + (value.length * 8-1) + ") : " + bitIndex);
    }

    public byte[] pop(int bitIndex, int bitLength) {
        byte[] array;
        if (bitLength%8!=0) {
            array = new byte[bitLength/8+1];
            int j=0;
            for(int i=0; i<array.length-1; i++) {
                array[i] = popAsByte(j, 8);
                j=j+8;
            }
            array[array.length-1]= popAsByte(j, bitLength-j);
        } else {
            array = new byte[bitLength/8];
            int j=0;
            for(int i=0; i<array.length; i++) {
                array[i] = popAsByte(j, 8);
                j+=8;
            }
        }
        return array;
    }

    public byte popAsByte(int bitIndex, int bitLength) {
        BitBuffer boo = new BitBuffer(1);
        boo.putAt(0, buffer.array(), bitIndex, bitLength);
        return boo.byteValue();
    }

    public short popAsShort(int bitIndex, int bitLength) {
        BitBuffer boo = new BitBuffer(2);
        boo.putAt(0, buffer.array(), bitIndex, bitLength);
        return boo.shortValue();
    }

    public int popAsInt(int bitIndex, int bitLength) {
        BitBuffer boo = new BitBuffer(4);
        boo.putAt(0, buffer.array(), bitIndex, bitLength);
        return boo.intValue();
    }

    public long popAsLong(int bitIndex, int bitLength) {
        BitBuffer boo = new BitBuffer(8);
        boo.putAt(0, buffer.array(), bitIndex, bitLength);
        return boo.longValue();
    }

    public byte popByteAt(int fromBitIndex) {
        return popAsByte(fromBitIndex, 8);
    }

    public short popShortAt(int fromBitIndex) {
        return popAsShort(fromBitIndex, 16);
    }

    public int popIntAt(int fromBitIndex) {
        return popAsInt(fromBitIndex, 32);
    }

    public long popLongAt(int fromBitIndex) {
        return popAsLong(fromBitIndex, 64);
    }

    public void putAt(int destBitIndex, byte[] ba, int srcBitIndex, int bitLength) {
        BitBuffer boo = BitBuffer.wrap(ba);
        int bitIndex = 0;
        while(bitIndex<bitLength) {
            if(boo.getBit(srcBitIndex)) {
                setBit(destBitIndex);
            } else {
                clearBit(destBitIndex);
            }
            srcBitIndex++;
            destBitIndex++;
            bitIndex++;
        }
    }

    public void putAt(int destBitIndex, byte b, int srcBitIndex, int bitLength) {
        putAt(destBitIndex, new byte[]{b}, srcBitIndex, bitLength);
    }

    public void putAt(int destBitIndex, short s, int srcBitIndex, int bitLength) {
        putAt(destBitIndex, ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(s).array(), srcBitIndex, bitLength);
    }

    public void putAt(int destBitIndex, int i, int srcBitIndex, int bitLength) {
        putAt(destBitIndex, ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(i).array(), srcBitIndex, bitLength);
    }

    public void putAt(int destBitIndex, long l, int srcBitIndex, int bitLength) {
        putAt(destBitIndex, ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(l).array(), srcBitIndex, bitLength);
    }

    public void putByteArrayAt(int destBitIndex, byte[] ba) {
        putAt(destBitIndex, ba, 0, ba.length * 8);
    }

    public void putByteAt(int destBitIndex, byte b) {
        putAt(destBitIndex, b, 0, 8);
    }

    public void putShortAt(int destBitIndex, short s) {
        putAt(destBitIndex, s, 0, 16);
    }

    public void putIntAt(int destBitIndex, int i) {
        putAt(destBitIndex, i, 0, 32);
    }

    public void putLongAt(int destBitIndex, long l) {
        putAt(destBitIndex, l, 0, 64);
    }

    public String toBinString() {
        StringBuffer strBuffer = new StringBuffer();
        for(int i=buffer.array().length*8-1; i>=0; i--) {
            if (getBit(i)) strBuffer.append("1");
            else strBuffer.append("0");
        }
        return strBuffer.toString();
    }
    
    public int size() {
    	return buffer.capacity();
    }

}
