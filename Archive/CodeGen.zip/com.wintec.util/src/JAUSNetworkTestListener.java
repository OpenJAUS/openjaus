import java.net.InetAddress;
import java.net.UnknownHostException;

import com.wintec.network.JAUSNetworkConnector;
import com.wintec.network.JAUSNetworkListener;
import com.wintec.util.HexString;

public class JAUSNetworkTestListener implements JAUSNetworkListener {

    public void packetReceived(InetAddress fromAddr, int port, byte[] data) {
        System.out.println(fromAddr+":"+port+" - "+HexString.bytesToHexString(data, " "));
    }

    public static void main(String[] args) {
    	JAUSNetworkConnector jausnet = new JAUSNetworkConnector();
    	jausnet.configNetwork("eth0",3794,"224.1.0.1");
    	byte[] message = new byte[]{1,2,3,4,5,6,7,8,9,10};
        
    	try {
			jausnet.send(InetAddress.getByName("192.168.12.3"), 3794, message);
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//jausnet.broadcast(message);
    	/*
    	jausnet.addMulticastListener(new JAUSNetworkTestListener());
        jausnet.getMulticastReceiver().startRunning();

        jausnet.addUnicastListener(new JAUSNetworkTestListener());
        jausnet.getUnicastReceiver().startRunning();
        */
        
    }

}
