/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.FixedField;

import java.util.Vector;

public class FixedFieldClass extends FieldClass {

    private FixedField fixedField;
    private String enclosingClassName;
    private int level;
    private boolean useWrapperClass;
    private RecordClass recordClass;

    public FixedFieldClass(RecordClass recordClass, FixedField fixedField, String enclosingClassName, int level) {
        this.fixedField = fixedField;
        this.enclosingClassName = enclosingClassName;
        this.level = level;
        this.recordClass = recordClass;
    }

    private CodeLines createCodes() throws RuntimeException {
        CodeLines codes = new CodeLines();
        String ffType = CodeGen.getVariableType(fixedField.getFieldType());
        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(ffType, getShortClassName(), false));

        codes.constructorLines.add(CodeGen.getVariableName(getShortClassName())+" = 0;");

        String tab = "";
        if (recordClass.hasPresenceVector() && fixedField.isOptional()) {
            tab = "    ";
            if (useWrapperClass) {
                codes.encoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
                codes.decoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            } else {
                codes.encoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
                codes.decoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            }
        }
        codes.encoderLines.add(tab+ffType+" "+CodeGen.getVariableName(getShortClassName()+"Temp")+";");
        codes.encoderLines.add(tab+CodeGen.getVariableName(getShortClassName()+"Temp")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName())+");");
        codes.encoderLines.add(tab+"memcpy(bytes+pos, &"+CodeGen.getVariableName(getShortClassName()+"Temp")+", sizeof("+ffType+"));");
        codes.encoderLines.add(tab+"pos += sizeof("+ffType+");");

        codes.decoderLines.add(tab+ffType+" "+CodeGen.getVariableName(getShortClassName()+"Temp")+";");
        codes.decoderLines.add(tab+"memcpy(&"+CodeGen.getVariableName(getShortClassName()+"Temp")+", bytes+pos, sizeof("+ffType+"));");
        codes.decoderLines.add(tab+CodeGen.getVariableName(getShortClassName())+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName()+"Temp")+");");
        codes.decoderLines.add(tab+"pos += sizeof("+ffType+");");

        if (recordClass.hasPresenceVector() && fixedField.isOptional()) {
            codes.encoderLines.add("}");
            codes.decoderLines.add("}");
        }

        if (fixedField.getScaleRange()!=null) {
            /// scaled integer (float to integer and integer to float conversion required)
            Vector<String> ffGetMethodCode = new Vector<String>();
            ffGetMethodCode.add("double realValue;");
            ffGetMethodCode.addAll(CodeGen.getIntegerToFloatConvCode(fixedField.getScaleRange(),fixedField.getFieldType(), CodeGen.getVariableName(getShortClassName()), "realValue"));
            ffGetMethodCode.add("return realValue;");
            
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("double", "get", getShortClassName(), null));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("double", getLongClassName()+"::get", getShortClassName(), null, ffGetMethodCode));

            Vector<String> ffSetMethodParam = new Vector<String>();
            ffSetMethodParam.add("double value");

            Vector<String> setCode = new Vector<String>();
            setCode.addAll(CodeGen.getFloatToIntegerConvCode(fixedField.getScaleRange(),fixedField.getFieldType(), "value", CodeGen.getVariableName(getShortClassName())));
            if (recordClass.hasPresenceVector() && fixedField.isOptional()) {
                if (useWrapperClass)
                    setCode.add(CodeGen.getVariableName("Parent")+"->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
                else
                    setCode.add("setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
            }
            setCode.add("return 0;");

            Vector<String> ffSetMethodCode = new Vector<String>();
            ffSetMethodCode.addAll(CodeGen.getValidationWrapper(fixedField.getScaleRange(), "value", setCode, null));
            ffSetMethodCode.add("return 1;");

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("int", "set", getShortClassName(), ffSetMethodParam));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName()+"::set", getShortClassName(), ffSetMethodParam,ffSetMethodCode));

        } else {
            /// normal integer value
            Vector<String> ffGetMethodCode = new Vector<String>();
            ffGetMethodCode.add("return "+ CodeGen.getVariableName(getShortClassName()) + ";");

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(ffType, "get", getShortClassName(), null));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(ffType, getLongClassName()+"::get", getShortClassName(), null, ffGetMethodCode));

            Vector<String> ffSetMethodParam = new Vector<String>();
            ffSetMethodParam.add(ffType+" value");

            Vector<String> setCode = new Vector<String>();
            setCode.add(CodeGen.getVariableName(getShortClassName())+" = value;");
            if (recordClass.hasPresenceVector() && fixedField.isOptional()) {
                if (useWrapperClass)
                    setCode.add(CodeGen.getVariableName("Parent")+"->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
                else
                    setCode.add("setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
            }
            setCode.add("return 0;");

            Vector<String> ffSetMethodCode = new Vector<String>();
            if (fixedField.getValueSet()!=null) {
                /// set method with validation
                ffSetMethodCode.addAll(CodeGen.getValidationWrapper(fixedField.getValueSet(), "value", setCode, null));
                ffSetMethodCode.add("return 1;");
            } else {
                /// set method without validation
                ffSetMethodCode.addAll(setCode);
            }

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("int", "set", getShortClassName(), ffSetMethodParam));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName()+"::set", getShortClassName(), ffSetMethodParam, ffSetMethodCode));
        }
        if (useWrapperClass) {
            /// adding encode/decode methods
            Vector<String> param = new Vector<String>();
            param.add("unsigned char *bytes");
            param.add("int &pos");

            Vector<String> param2 = new Vector<String>();
            param2.add("unsigned char *bytes");
            param2.add("int &pos");

            /// class encoder
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "encode", null, param));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::encode", null, param, codes.encoderLines));

            /// class decoder
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "decode", null, param2));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::decode", null, param2, codes.decoderLines));

            return getWrapperClass(level, enclosingClassName, codes);
        }
		return codes;
    }

    public CodeLines getCodeLines(boolean useWrapperClass) {
        this.useWrapperClass = useWrapperClass;
        if (useWrapperClass) {
            this.level = level + 1;
        }
        return createCodes();
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(fixedField.getName());
    }

    public String getLongClassName() {
        if (useWrapperClass) {
            return enclosingClassName+"::"+getShortClassName();
        }
		return enclosingClassName;
    }
}
