/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.BitField;
import com.wintec.jmapiCodeGenerator.binding.SubField;
import com.wintec.jmapiCodeGenerator.binding.ValueRange;

import java.util.Vector;

public class BitFieldClass extends FieldClass {

    private BitField bitField;
    private String enclosingClassName;
    private int level;
    private RecordClass recordClass;

    public BitFieldClass(RecordClass recordClass, BitField bitField, String enclosingClassName, int level) throws RuntimeException {
        this.bitField = bitField;
        String enclosingShortClassName = enclosingClassName.substring(enclosingClassName.lastIndexOf("::")+2);
        if (enclosingShortClassName.equalsIgnoreCase(getShortClassName())) {
            throw new RuntimeException(getShortClassName()+ " : a nested element cannot have the same name as the immediately enclosing element.");
        }
        this.enclosingClassName = enclosingClassName;
        this.level = level+1;
        this.recordClass = recordClass;
    }

    private CodeLines createCodes() throws RuntimeException {

        CodeLines codes = new CodeLines();

        String bfType = CodeGen.getVariableType(bitField.getFieldTypeUnsigned());

        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(bfType, getShortClassName(), false));

        codes.constructorLines.add(CodeGen.getVariableName(getShortClassName())+" = 0;");

        String tab = "";
        if (recordClass.hasPresenceVector() && bitField.isOptional()) {
            codes.encoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            codes.decoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            tab = "    ";
        }
        codes.encoderLines.add(tab+bfType+" "+CodeGen.getVariableName(getShortClassName()+"Temp")+";");
        codes.encoderLines.add(tab+CodeGen.getVariableName(getShortClassName()+"Temp")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName())+");");
        codes.encoderLines.add(tab+"memcpy(bytes+pos, &"+CodeGen.getVariableName(getShortClassName()+"Temp")+", sizeof("+bfType+"));");
        codes.encoderLines.add(tab+"pos += sizeof("+bfType+");");

        codes.decoderLines.add(tab+bfType+" "+CodeGen.getVariableName(getShortClassName()+"Temp")+";");
        codes.decoderLines.add(tab+"memcpy(&"+CodeGen.getVariableName(getShortClassName()+"Temp")+", bytes+pos, sizeof("+bfType+"));");
        codes.decoderLines.add(tab+CodeGen.getVariableName(getShortClassName())+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName()+"Temp")+");");
        codes.decoderLines.add(tab+"pos += sizeof("+bfType+");");

        if (recordClass.hasPresenceVector() && bitField.isOptional()) {
            codes.encoderLines.add("}");
            codes.decoderLines.add("}");
        }

        /*
        Vector<String> bfGetMethodCode = new Vector<String>();
        bfGetMethodCode.add("return "+ CodeGen.getVariableName(getShortClassName())+";");

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(bfType, "get", "Value", null));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition(bfType, getLongClassName() +"::get", "Value", null, bfGetMethodCode));

        Vector<String> bfSetMethodParam = new Vector<String>();
        bfSetMethodParam.add(bfType+" value");

        Vector<String> bfSetMethodCode = new Vector<String>();
        bfSetMethodCode.add(CodeGen.getVariableName(getShortClassName()) + " = value;");
        if (recordClass.hasPresenceVector()) bfSetMethodCode.add("parent->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
        bfSetMethodCode.add("return 0;");

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("int", "set", "Value", bfSetMethodParam));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName() +"::set", "Value", bfSetMethodParam, bfSetMethodCode));
        */
        for(SubField subField : bitField.getSubField()) {
            /// get value size
            int fromIndex = subField.getBitRange().getFromIndex();
            int toIndex = subField.getBitRange().getToIndex();
            int size = toIndex-fromIndex+1;

            String offset = "";
            String sfType = CodeGen.getVariableType("unsigned long integer");
            if (size<=8) {
                sfType = CodeGen.getVariableType("unsigned byte");
            } else if (size<=16) {
                sfType = CodeGen.getVariableType("unsigned short integer");
            } else if (size<=32) {
                sfType = CodeGen.getVariableType("unsigned integer");
            }
            if (subField.getValueSet()!=null && subField.getValueSet().isOffsetToLowerLimit()) {
                long min = Long.MAX_VALUE;
                long max = 0;
                for(Object obj:subField.getValueSet().getValueRangeOrValueEnum()) {
                    if (obj instanceof ValueRange) {
                        long localMax = Long.valueOf(((ValueRange)obj).getUpperLimit());
                        long localMin = Long.valueOf(((ValueRange)obj).getLowerLimit());
                        if (localMin<min) min=localMin;
                        if (localMax<max) max=localMax;
                    }
                }
                if (min!=Long.MAX_VALUE) {
                    offset = min+"+";
                }
                if (max!=0) {
                    if (max<256) {
                        sfType = CodeGen.getVariableType("unsigned byte");
                    } else if (max<65536) {
                        sfType = CodeGen.getVariableType("unsigned short integer");
                    } else if (max<40404040404L) {
                        sfType = CodeGen.getVariableType("unsigned integer");
                    }
                }
            }
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(sfType,"get",subField.getName(), null));

            Vector<String> sfGetMethodCode = new Vector<String>();
            sfGetMethodCode.add("bitset<sizeof("+CodeGen.getVariableName(getShortClassName())+")*8> bfbs("+CodeGen.getVariableName(getShortClassName())+");");
            sfGetMethodCode.add("bitset<"+size+"> sfbs;");
            sfGetMethodCode.add("for(int i=0; i<"+size+";i++) {");
            sfGetMethodCode.add("    sfbs[i] = bfbs[i+"+fromIndex+"];");
            sfGetMethodCode.add("}");
            sfGetMethodCode.add("return ("+sfType+")("+offset+"sfbs.to_ulong());");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(sfType, getLongClassName() +"::get",subField.getName(), null, sfGetMethodCode));

            Vector<String> sfSetMethodParam = new Vector<String>();
            sfSetMethodParam.add(bfType+" value");
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("int", "set", subField.getName(), sfSetMethodParam));

            Vector<String> setCode = new Vector<String>();
            setCode.add("bitset<sizeof("+CodeGen.getVariableName(getShortClassName())+")*8> bfbs("+CodeGen.getVariableName(getShortClassName())+");");
            setCode.add("bitset<"+size+"> sfbs("+offset+"value);");
            setCode.add("for(int i=0; i<"+size+";i++) {");
            setCode.add("    bfbs[i+"+fromIndex+"] = sfbs[i];");
            setCode.add("}");
            setCode.add(CodeGen.getVariableName(getShortClassName())+" = ("+bfType+")bfbs.to_ulong();");
            if (recordClass.hasPresenceVector() && bitField.isOptional()) setCode.add(CodeGen.getVariableName("Parent")+"->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
            setCode.add("return 0;");
            Vector<String> sfSetMethodCode = new Vector<String>();
            if (subField.getValueSet()!=null) {
                sfSetMethodCode.addAll(CodeGen.getValidationWrapper(subField.getValueSet(), "value", setCode, null));
                sfSetMethodCode.add("return 1;");
            } else {
                sfSetMethodCode.addAll(setCode);
            }
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName() +"::set", subField.getName(),
                sfSetMethodParam, sfSetMethodCode));
        }

        /// adding encode/decode methods
        Vector<String> param = new Vector<String>();
        param.add("unsigned char *bytes");
        param.add("int &pos");

        Vector<String> param2 = new Vector<String>();
        param2.add("unsigned char *bytes");
        param2.add("int &pos");

        /// class encoder
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "encode", null, param));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::encode", null, param, codes.encoderLines));

        /// class decoder
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "decode", null, param2));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::decode", null, param2, codes.decoderLines));

        return getWrapperClass(level, enclosingClassName, codes);
    }

    public CodeLines getCodeLines(boolean dummy) {
        return createCodes();
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(bitField.getName());
    }

    public String getLongClassName() {
        return enclosingClassName+"::"+getShortClassName();
    }
}
