/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

import com.wintec.jmapiCodeGenerator.binding.*;
import com.wintec.util.HexString;

public class ServiceClass {

    private ServiceDef serviceDef;
    private String serviceClassName;
    private String namespace;
    private String protocolBehaviorMethods;

    private StringBuffer headerIncludes;
    private StringBuffer usingNamespace;
    private StringBuffer constructorCode;
    private StringBuffer destructorCode;
    
    private Hashtable<String, String> sourceCodeSet;
    
    public static String makeNamespace(String id, String version) {
        char[] ns = (id+"_"+version).toCharArray();
        for(int i=0; i<ns.length; i++) {
            if (!((ns[i]>='0' && ns[i]<='9')
                ||(ns[i]>='A' && ns[i]<='Z')
                ||(ns[i]>='a' && ns[i]<='z'))) {
                ns[i]='_';
            }
        }
        return new String(ns);
	}

	public ServiceClass(ServiceDef serviceDef) {
        sourceCodeSet = new Hashtable<String, String>();
        
        headerIncludes = new StringBuffer();
        usingNamespace = new StringBuffer("using namespace "+CodeGen.ROOT_NAMESPACE+";"+CodeGen.LINE_END);
        constructorCode = new StringBuffer();
        destructorCode = new StringBuffer();
        
        this.serviceDef = serviceDef;
        serviceClassName = serviceDef.getName();
        namespace = makeNamespace(serviceDef.getId(),serviceDef.getVersion());

        constructorCode.append(CodeGen.tabs(0)).append("mID = ").append(serviceClassName).append("::ID;").append(CodeGen.LINE_END);
        constructorCode.append(CodeGen.tabs(0)).append("mVersion = ").append(serviceClassName).append("::VERSION;").append(CodeGen.LINE_END);
        constructorCode.append(CodeGen.tabs(0)).append("mServiceName = ").append(serviceClassName).append("::NAME;").append(CodeGen.LINE_END);
        //constructorCode.append(CodeGen.tabs(0)).append("context = new ").append(serviceClassName).append("Context(*this);").append(CodeGen.LINE_END);

        //destructorCode.append(CodeGen.tabs(0)).append("delete context;").append(CodeGen.LINE_END);
        
        /// Process Message Set
        for (int i=0; i<serviceDef.getMessageSet().getMessageDef().size();i++) {
        	MessageDef msg = serviceDef.getMessageSet().getMessageDef().get(i);
            // get message file header list
            headerIncludes.append("#include <").append(namespace).append("/").append(msg.getName()).append(".h>").append(CodeGen.LINE_END);
            // create message list
            if (msg.getType().equalsIgnoreCase("input")) {
            	constructorCode.append(CodeGen.tabs(0)).append("mInputMessageList.insert(0x").append(HexString.bytesToHexString(msg.getMessageId(),"")).append(");").append(CodeGen.LINE_END);
            } else if (msg.getType().equalsIgnoreCase("output")) {
            	constructorCode.append(CodeGen.tabs(0)).append("mOutputMessageList.insert(0x").append(HexString.bytesToHexString(msg.getMessageId(),"")).append(");").append(CodeGen.LINE_END);
            }
        }
        
        /// Process Protocol Behavior Actions and Guard conditions
        HashMap<String,String> voidMethodMap = new HashMap<String,String>();
        HashMap<String,String> boolMethodMap = new HashMap<String,String>();
        ProtocolBehavior pb = serviceDef.getProtocolBehavior();
        for(Map map:pb.getMap()) {
        	for(State state:map.getState()) {
        		if (state.getEntry()!=null) {
        			for(Action action:state.getEntry().getAction()) {
		        		voidMethodMap.put(action.getName(), action.getName() + "Action()");
        			}
        		}
        		if (state.getExit()!=null) {
        			for(Action action:state.getExit().getAction()) {
		        		voidMethodMap.put(action.getName(), action.getName() + "Action()");
        			}
        		}
        		for(Transition tr:state.getTransition()) {
	    			HashMap<String, String> parameterMap = new HashMap<String,String>();
	        		StringBuffer paramString = new StringBuffer();
	        		StringBuffer paramSignature = new StringBuffer();
	        		if (tr.getParameter()!=null) {
		        		for(Parameter pm:tr.getParameter()) {
		        			parameterMap.put(pm.getVariable(), pm.getType());
		        			if (paramString.length()>0) paramString.append(", ");
		        			paramString.append(pm.getType()).append(" *").append(pm.getVariable());
		        			paramSignature.append(pm.getType());
		    			}
					}
        			for(Action action:tr.getAction()) {
	    				String args = "";
		        		String signature = action.getName();
		        		if (action.getArgument()!=null) {
	    					for(Argument arg:action.getArgument()) {
	    						String variable = arg.getVariable();
	    						String type = parameterMap.get(variable);
	    						if (args.length()!=0) args += ", ";
	    						args += type +" *"+variable;
	    						signature += type;
	    					}
	    				}
		        		voidMethodMap.put(signature, action.getName() + "Action("+args+")");
        			}
	    			Guard guardcondition = tr.getGuard();
	    			if (guardcondition!=null) {
	    				boolMethodMap.put(guardcondition.getCondition()+paramSignature.toString(), guardcondition.getCondition()+"("+paramString.toString()+")");
	    			}
        		}
	    		DefaultTransition defaultTr = state.getDefaultTransition();
				if (defaultTr!=null) {
		    		if (defaultTr.getAction()!=null) {
			    		for(Action action:defaultTr.getAction()) {
			    			voidMethodMap.put(action.getName(), action.getName() + "Action()");
						}
					}
			    	Guard guardcondition = defaultTr.getGuard();
					if (guardcondition!=null) {
						boolMethodMap.put(guardcondition.getCondition(), guardcondition.getCondition()+"()");
					}
				}
        	}
        	DefaultState defaultState = map.getDefaultState();
    		if (defaultState!=null) {
	        	for(Transition tr:defaultState.getTransition()) {
	    			HashMap<String, String> parameterMap = new HashMap<String,String>();
	        		StringBuffer paramString = new StringBuffer();
	        		StringBuffer paramSignature = new StringBuffer();
	    			if (tr.getParameter()!=null) {
		        		for(Parameter pm:tr.getParameter()) {
		        			parameterMap.put(pm.getVariable(), pm.getType());
		        			if (paramString.length()>0) paramString.append(", ");
		        			paramString.append(pm.getType()).append(" *").append(pm.getVariable());
		        			paramSignature.append(pm.getType());
		    			}
					}
		        	for(Action action:tr.getAction()) {
	    				String args = "";
		        		String signature = action.getName();
		        		if (action.getArgument()!=null) {
	    					for(Argument arg:action.getArgument()) {
	    						String variable = arg.getVariable();
	    						String type = parameterMap.get(variable);
	    						if (args.length()!=0) args += ", ";
	    						args += type +" *"+variable;
	    						signature += type;
	    					}
	    				}
		        		voidMethodMap.put(signature, action.getName() + "Action("+args+")");
	    			}
	    			Guard guardcondition = tr.getGuard();
	    			if (guardcondition!=null) {
	    				boolMethodMap.put(guardcondition.getCondition()+paramSignature.toString(), guardcondition.getCondition()+"("+paramString.toString()+")");
	    			}
	    		}
	    		DefaultTransition defaultTr = defaultState.getDefaultTransition();
				if (defaultTr!=null) {
		    		if (defaultTr.getAction()!=null) {
			    		for(Action action:defaultTr.getAction()) {
			    			voidMethodMap.put(action.getName(), action.getName() + "Action()");
						}
					}
			    	Guard guardcondition = defaultTr.getGuard();
					if (guardcondition!=null) {
						boolMethodMap.put(guardcondition.getCondition(), guardcondition.getCondition()+"()");
					}
				}
    		}
        }
        StringBuffer pbclines = new StringBuffer();
        Iterator<String> iterator = voidMethodMap.keySet().iterator();
        while(iterator.hasNext()) {
        	pbclines.append(CodeGen.tabs(0)).append("virtual void ").append(voidMethodMap.get(iterator.next())).append("=0;").append(CodeGen.LINE_END);
        }
        iterator = boolMethodMap.keySet().iterator();
        while(iterator.hasNext()) {
        	pbclines.append(CodeGen.tabs(0)).append("virtual bool ").append(boolMethodMap.get(iterator.next())).append("=0;").append(CodeGen.LINE_END);
        }
        protocolBehaviorMethods = pbclines.toString();
	}
	
	public String getNamespace() {
        return namespace;
    }

    public ServiceDef getServiceDef() {
        return serviceDef;
    }

    public String getName() {
        return serviceClassName;
    }
    
    public Hashtable<String, String> getSourceCodeSet() {
        return sourceCodeSet;
    }

    public String getDirName() {
        return namespace;    
    }

    public void startProcess() {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMMM yyyy, hh:mm:ss z");

        // load templates for service and replace contents
        String service_h = CodeGen.getTemplate("service_base.h.tpl")
            .replace("%time_stamp%", sdf.format(cal.getTime()))
            .replace("%root_namespace%", CodeGen.ROOT_NAMESPACE)
            .replace("%name_space%", namespace)
            .replace("%service_name%", serviceClassName)
            .replace("%required_file_header_include%", headerIncludes.toString())
        	.replace("%additional_using_namespace%", usingNamespace.toString())
        	.replace("%protocol_behavior_action_and_guard_conditions%",protocolBehaviorMethods);

        String service_cpp = CodeGen.getTemplate("service_base.cpp.tpl")
	        .replace("%time_stamp%", sdf.format(cal.getTime()))
	        .replace("%root_namespace%", CodeGen.ROOT_NAMESPACE)
	        .replace("%name_space%", namespace)
	        .replace("%service_name%", serviceClassName)
	        .replace("%service_id%", serviceDef.getId())
	        .replace("%service_version%",serviceDef.getVersion())
	        .replace("%constructor_code%", constructorCode.toString())
	        .replace("%destructor_code%", destructorCode.toString());

        sourceCodeSet.put(serviceClassName+".h", service_h);
        sourceCodeSet.put(serviceClassName+".cpp", service_cpp);

        for(MessageDef msg:serviceDef.getMessageSet().getMessageDef()) {
            MessageClass msgClass = new MessageClass(this, msg);
            msgClass.startProcess();
            sourceCodeSet.put(msgClass.getShortClassName()+".h", msgClass.getHppCode());
            sourceCodeSet.put(msgClass.getShortClassName()+".cpp", msgClass.getCppCode());
        }

    }
}
