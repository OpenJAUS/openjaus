/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.*;
import com.wintec.util.HexString;

import java.util.HashSet;
import java.util.Vector;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class MessageClass {

    private MessageDef messageDef;
    private ServiceClass serviceClass;
    private String hppCode;
    private String cppCode;

    private int level = 1;
    private HashSet<String> definedClassList;

    public MessageClass(ServiceClass service, MessageDef msgDef) {
        messageDef = msgDef;
        serviceClass = service;
        definedClassList = new HashSet<String>();
    }

    public MessageDef getMessageDef() {
        return messageDef;
    }

    public String getHppCode() {
        return hppCode;
    }

    public String getCppCode() {
        return cppCode;
    }

    public void startProcess() throws RuntimeException {
        CodeLines codes = new CodeLines();

        // make service class friend to this message class
        //codes.protectedMethods.add(CodeGen.tabs(level)+"friend class "+serviceClass.getName()+";");
        //codes.protectedMethods.add(CodeGen.tabs(level)+"friend class "+serviceClass.getName()+"Client;");

        String message_id = "0x"+ HexString.bytesToHexString(messageDef.getMessageId(),"");
        String is_command = (messageDef.isIsCommand()?"true":"false");

        codes.publicAttributes.add(CodeGen.tabs(level)+"static const unsigned short MessageId = "+message_id+";");
        codes.publicAttributes.add(CodeGen.tabs(level)+"jUnsignedShortInteger getMessageId() {return MessageId;};");
        
        /// constructor code
        codes.constructorLines.add("mServiceId = \""+ serviceClass.getServiceDef().getId() +"\";");
        codes.constructorLines.add("mIsCommand = "+is_command+";");

        codes.encoderLines.add("int pos = 0;");
        codes.decoderLines.add("int pos = 0;");

        /// processing body
        RecordCount recordCount = messageDef.getBody().getRecordCount();
        if(recordCount!=null) {
            /// record_count
            String recordCountType = CodeGen.getVariableType(recordCount.getCountField().getFieldTypeUnsigned());
            String recordCountName = CodeGen.upperCaseFirstLetter(recordCount.getName());
            codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(recordCountType, recordCountName, false));
            codes.constructorLines.add(CodeGen.getVariableName(recordCountName)+" = 0;");

            codes.encoderLines.add("memcpy(bytes+pos, &"+CodeGen.getVariableName(recordCountName)+", sizeof("+CodeGen.getVariableName(recordCountName)+"));");
            codes.encoderLines.add("pos += sizeof("+CodeGen.getVariableName(recordCountName)+");");

            codes.decoderLines.add("memcpy(&"+CodeGen.getVariableName(recordCountName)+", bytes+pos, sizeof("+CodeGen.getVariableName(recordCountName)+"));");
            codes.decoderLines.add("pos += sizeof("+CodeGen.getVariableName(recordCountName)+");");

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(recordCountType, "get", recordCountName, null));
            Vector<String> rcGetMethod = new Vector<String>();
            rcGetMethod.add("return "+ CodeGen.getVariableName(recordCountName) + ";");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(recordCountType, getLongClassName() +"::get", recordCountName, null,rcGetMethod));

            /// list of records
            Record record = messageDef.getBody().getRecord();
            /// creating record wrapper class
            RecordClass recordClass = new RecordClass(record, getLongClassName(), level, definedClassList);
            if (!definedClassList.contains(recordClass.getLongClassName())) {
                codes.add(recordClass.getCodeLines(CodeGen.WITH_WRAPPER_CLASS));
                definedClassList.add(recordClass.getLongClassName());
            } else {
                throw new RuntimeException("Duplicated element names: "+ recordClass.getLongClassName());
            }
            codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("vector<"+recordClass.getLongClassName()+"*>", recordClass.getShortClassName(), false));

            codes.destructorLines.add("for("+recordCountType+" i=0; i<"+CodeGen.getVariableName(recordCountName)+"; i++) {");
            codes.destructorLines.add("    delete "+ CodeGen.getVariableName(recordClass.getShortClassName())+".at(i);");
            codes.destructorLines.add("}");

            codes.encoderLines.add("for("+recordCountType+" i=0; i<"+CodeGen.getVariableName(recordCountName)+"; i++) {");
            codes.encoderLines.add("    "+ CodeGen.getVariableName(recordClass.getShortClassName())+".at(i)->encode(bytes, pos);");
            codes.encoderLines.add("}");

            codes.decoderLines.add("for("+recordCountType+" i=0; i<"+CodeGen.getVariableName(recordCountName)+"; i++) {");
            codes.decoderLines.add("    "+CodeGen.getVariableName(recordClass.getShortClassName())+".push_back(new "+recordClass.getShortClassName()+"());");
            codes.decoderLines.add("    "+CodeGen.getVariableName(recordClass.getShortClassName())+".back()->decode(bytes, pos);");
            codes.decoderLines.add("}");

            Vector<String> rGetMethodParam = new Vector<String>();
            rGetMethodParam.add(recordCountType+" index");

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(recordClass.getLongClassName(), "*get", recordClass.getShortClassName(), rGetMethodParam));
            Vector<String> rGetMethodCode = new Vector<String>();
            rGetMethodCode.add("return "+ CodeGen.getVariableName(recordClass.getShortClassName()) + ".at(index);");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(recordClass.getLongClassName(), "*"+ getLongClassName() +"::"+"get", recordClass.getShortClassName(), rGetMethodParam,rGetMethodCode));

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(recordClass.getLongClassName(), "*append", recordClass.getShortClassName(), null));
            Vector<String> rAppendMethodCode = new Vector<String>();
            rAppendMethodCode.add(CodeGen.getVariableName(recordClass.getShortClassName()) + ".push_back(new "+recordClass.getLongClassName()+"());");
            rAppendMethodCode.add(CodeGen.getVariableName(recordCountName) + "++;");
            rAppendMethodCode.add("return "+CodeGen.getVariableName(recordClass.getShortClassName())+".back();");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(recordClass.getLongClassName(), "*"+ getLongClassName() +"::"+"append", recordClass.getShortClassName(), null,rAppendMethodCode));

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(recordClass.getLongClassName(), "*insert", recordClass.getShortClassName(), rGetMethodParam));
            Vector<String> rInsertMethodCode = new Vector<String>();
            //rInsertMethodCode.add("vector<"+recordClass.getLongClassName()+"*>::iterator itr = "+CodeGen.getVariableName(recordClass.getShortClassName())+".insert("
            //    +CodeGen.getVariableName(recordClass.getShortClassName())+".begin()+index, new "+recordClass.getLongClassName()+"());");
            rInsertMethodCode.add(CodeGen.getVariableName(recordCountName) + "++;");
            rInsertMethodCode.add("return "+ CodeGen.getVariableName(recordClass.getShortClassName()) + ".at(index);");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(recordClass.getLongClassName(), "*"+ getLongClassName() +"::"+"insert", recordClass.getShortClassName(), rGetMethodParam,rInsertMethodCode));

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "remove", recordClass.getShortClassName(), rGetMethodParam));
            Vector<String> rRemoveMethodCode = new Vector<String>();
            rRemoveMethodCode.add("delete "+CodeGen.getVariableName(recordClass.getShortClassName())+".at(index);");
            rRemoveMethodCode.add(CodeGen.getVariableName(recordClass.getShortClassName()) + ".erase("+CodeGen.getVariableName(recordClass.getShortClassName())+".begin()+index);");
            rRemoveMethodCode.add(CodeGen.getVariableName(recordCountName) + "--;");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName() +"::"+"remove", recordClass.getShortClassName(), rGetMethodParam,rRemoveMethodCode));
        } else {
            /// a record
            Record record = messageDef.getBody().getRecord();
            if (record!=null) {
                RecordClass recordClass = new RecordClass(record, getLongClassName(), level, definedClassList);
                codes.add(recordClass.getCodeLines(CodeGen.WITHOUT_WRAPPER_CLASS));
            }
        }
        java.util.List<Object> listList = messageDef.getBody().getListCountAndListOrDeclaredList();
        for(int i=0; i<listList.size();i++) {
            if (listList.get(i) instanceof ListCount) {
                /// get list_count
                ListCount listCount = (ListCount)listList.get(i);
                String listCountType = CodeGen.getVariableType(listCount.getCountField().getFieldTypeUnsigned());
                String listCountName = CodeGen.upperCaseFirstLetter(listCount.getName());
                codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(listCountType, listCountName, false));
                codes.constructorLines.add(CodeGen.getVariableName(listCountName)+" = 0;");

                codes.encoderLines.add("memcpy(bytes+pos, &"+CodeGen.getVariableName(listCountName)+", sizeof("+CodeGen.getVariableName(listCountName)+"));");
                codes.encoderLines.add("pos += sizeof("+CodeGen.getVariableName(listCountName)+");");

                codes.decoderLines.add("memcpy(&"+CodeGen.getVariableName(listCountName)+", bytes+pos, sizeof("+CodeGen.getVariableName(listCountName)+"));");
                codes.decoderLines.add("pos += sizeof("+CodeGen.getVariableName(listCountName)+");");

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listCountType, "get", listCountName, null));
                Vector<String> lcGetMethodCode = new Vector<String>();
                lcGetMethodCode.add("return "+ CodeGen.getVariableName(listCountName) + ";");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listCountType, getLongClassName() +"::"+"get", listCountName, null,lcGetMethodCode));

                /// get list
                List subList = (List)listList.get(++i);
                /// list class
                ListClass listClass = new ListClass(subList, getLongClassName(), level);
                if (!definedClassList.contains(listClass.getLongClassName())) {
                    codes.add(listClass.getCodeLines());
                    definedClassList.add(listClass.getLongClassName());
                } else {
                    throw new RuntimeException("Duplicated element names: "+listClass.getLongClassName());
                }
                codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("vector<"+listClass.getLongClassName()+"*>", listClass.getShortClassName(), false));

                codes.destructorLines.add("for("+listCountType+" i=0; i<"+CodeGen.getVariableName(listCountName)+"; i++) {");
                codes.destructorLines.add("    delete "+ CodeGen.getVariableName(listClass.getShortClassName())+".at(i);");
                codes.destructorLines.add("}");

                codes.encoderLines.add("for("+listCountType+" i=0; i<"+CodeGen.getVariableName(listCountName)+"; i++) {");
                codes.encoderLines.add("    "+ CodeGen.getVariableName(listClass.getShortClassName())+".at(i)->encode(bytes, pos);");
                codes.encoderLines.add("}");

                codes.decoderLines.add("for("+listCountType+" i=0; i<"+CodeGen.getVariableName(listCountName)+"; i++) {");
                codes.decoderLines.add("    "+CodeGen.getVariableName(listClass.getShortClassName())+".push_back(new "+listClass.getShortClassName()+"());");
                codes.decoderLines.add("    "+CodeGen.getVariableName(listClass.getShortClassName())+".back()->decode(bytes, pos);");
                codes.decoderLines.add("}");

                Vector<String> lGetMethodParam = new Vector<String>();
                lGetMethodParam.add(listCountType+" index");

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listClass.getLongClassName(), "*get", listClass.getShortClassName(), lGetMethodParam));
                Vector<String> lGetMethodCode = new Vector<String>();
                lGetMethodCode.add("return "+ CodeGen.getVariableName(listClass.getShortClassName()) + ".at(index);");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listClass.getLongClassName(), "*"+ getLongClassName() +"::"+"get", listClass.getShortClassName(), lGetMethodParam,lGetMethodCode));

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listClass.getLongClassName(), "*append", listClass.getShortClassName(), null));
                Vector<String> lAppendMethodCode = new Vector<String>();
                lAppendMethodCode.add(CodeGen.getVariableName(listClass.getShortClassName()) + ".push_back(new "+listClass.getLongClassName()+"());");
                lAppendMethodCode.add(CodeGen.getVariableName(listCountName) + "++;");
                lAppendMethodCode.add("return "+CodeGen.getVariableName(listClass.getShortClassName())+".back();");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listClass.getLongClassName(), "*"+ getLongClassName() +"::"+"append", listClass.getShortClassName(), null,lAppendMethodCode));

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listClass.getLongClassName(), "*insert", listClass.getShortClassName(), lGetMethodParam));
                Vector<String> lInsertMethodCode = new Vector<String>();
                //lInsertMethodCode.add("vector<"+listClass.getLongClassName()+"*>::iterator itr = "+CodeGen.getVariableName(listClass.getShortClassName())+".insert("
                //    +CodeGen.getVariableName(listClass.getShortClassName())+".begin()+index, new "+listClass.getLongClassName()+"());");
                lInsertMethodCode.add(CodeGen.getVariableName(listCountName) + "++;");
                lInsertMethodCode.add("return "+ CodeGen.getVariableName(listClass.getShortClassName()) + ".at(index);");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listClass.getLongClassName(), "*"+ getLongClassName() +"::"+"insert", listClass.getShortClassName(), lGetMethodParam,lInsertMethodCode));

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "remove", listClass.getShortClassName(), lGetMethodParam));
                Vector<String> lRemoveMethodCode = new Vector<String>();
                lRemoveMethodCode.add("delete "+CodeGen.getVariableName(listClass.getShortClassName())+".at(index);");
                lRemoveMethodCode.add(CodeGen.getVariableName(listClass.getShortClassName()) + ".erase("+CodeGen.getVariableName(listClass.getShortClassName())+".begin()+index);");
                lRemoveMethodCode.add(CodeGen.getVariableName(listCountName) + "--;");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName() +"::"+"remove", listClass.getShortClassName(), lGetMethodParam,lRemoveMethodCode));


            } else if (listList.get(i) instanceof List) {
                /// get list
                List list = (List)listList.get(i);
                /// list class
                ListClass listClass = new ListClass(list, getLongClassName(), level);
                if (!definedClassList.contains(listClass.getLongClassName())) {
                    codes.add(listClass.getCodeLines());
                    definedClassList.add(listClass.getLongClassName());
                } else {
                    throw new RuntimeException("Duplicated element names: "+ listClass.getLongClassName());
                }
                /// list member variable
                codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(listClass.getLongClassName(), listClass.getShortClassName(), false));

                codes.encoderLines.add(CodeGen.getVariableName(listClass.getShortClassName())+".encode(bytes, pos);");
                codes.decoderLines.add(CodeGen.getVariableName(listClass.getShortClassName())+".decode(bytes, pos);");

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listClass.getLongClassName(), "*get", listClass.getShortClassName(), null));
                Vector<String> lGetMethodCode = new Vector<String>();
                lGetMethodCode.add("return &"+ CodeGen.getVariableName(listClass.getShortClassName()) + ";");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listClass.getLongClassName(), "*"+ getLongClassName() +"::"+"get", listClass.getShortClassName(), null,lGetMethodCode));
            }
        }

        /// message default class constructor
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, getLongClassName(), null, null));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName() +"::"+ getShortClassName(), null, null, codes.constructorLines));

        /// message second class constructor
        Vector<String> constParam = new Vector<String>();
        constParam.add("unsigned char *bytes");
        codes.constructorLines.add("decode(bytes);");
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, getLongClassName(), null, constParam));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName() +"::"+ getShortClassName(), null, constParam, codes.constructorLines));

        /// message class destructor
        if (!codes.destructorLines.isEmpty()) {
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, "~"+ getLongClassName(), null, null));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName()+"::~"+ getShortClassName(), null, null, codes.destructorLines));
        }

        /// class encoder
        Vector<String> param1 = new Vector<String>();
        param1.add("unsigned char *bytes");
        codes.encoderLines.add("return pos;");
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("virtual int", "encode", null, param1));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName()+"::encode", null, param1, codes.encoderLines));

        /// class decoder
        Vector<String> param2 = new Vector<String>();
        param2.add("unsigned char *bytes");
        codes.decoderLines.add("return pos;");
        codes.protectedMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("virtual int", "decode", null, param2));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName()+"::decode", null, param2, codes.decoderLines));

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMMM yyyy, hh:mm:ss z");

    	String commentLine = 
    		 "////////////////////////////////////////////////////////////////////////////////////////"+CodeGen.LINE_END
    		+"// This file was generated by the JSIDL Code Generator with JSIDL specification V0.9."+CodeGen.LINE_END
    		+"// Any modifications to this file will be lost upon recompilation of the source xml."+CodeGen.LINE_END
    		+"// Generated on: "+sdf.format(cal.getTime())+CodeGen.LINE_END                 
    		+"////////////////////////////////////////////////////////////////////////////////////////"+CodeGen.LINE_END;

    	hppCode = commentLine+CodeGen.LINE_END
    		+"#ifndef "+getLongClassName().toUpperCase()+"_H_"+CodeGen.LINE_END
    		+"#define "+getLongClassName().toUpperCase()+"_H_"+CodeGen.LINE_END
    		+CodeGen.LINE_END
    		+"#include <bitset>"+CodeGen.LINE_END
    		+"#include <vector>"+CodeGen.LINE_END
    		+"#include <JausUtils.h>"+CodeGen.LINE_END
    		+"#include <Message.h>"+CodeGen.LINE_END+CodeGen.LINE_END
    		+"using namespace std;"+CodeGen.LINE_END
    		+"using namespace "+CodeGen.ROOT_NAMESPACE+";"+CodeGen.LINE_END
    		+CodeGen.LINE_END
    		+"namespace "+serviceClass.getNamespace()+" {"+CodeGen.LINE_END
    		+CodeGen.LINE_END
    		+codes.getWrapperClassCode(CodeGen.tabs(0), getShortClassName(), "public Message")+CodeGen.LINE_END
    		+"};"+CodeGen.LINE_END+CodeGen.LINE_END
    		+"#endif /* "+getLongClassName().toUpperCase()+"_H_ */"+CodeGen.LINE_END;

    	cppCode = commentLine+CodeGen.LINE_END
        	+"#include <"+serviceClass.getNamespace()+"/"+getLongClassName()+".h>"+CodeGen.LINE_END
        	+CodeGen.LINE_END
        	+"namespace "+serviceClass.getNamespace()+" {"+CodeGen.LINE_END
        	+CodeGen.LINE_END
        	+codes.getMethodCodeString()+CodeGen.LINE_END
        	+"}"+CodeGen.LINE_END;
        	
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(messageDef.getName());
    }

    public String getLongClassName() {
        return getShortClassName();
    }
}
