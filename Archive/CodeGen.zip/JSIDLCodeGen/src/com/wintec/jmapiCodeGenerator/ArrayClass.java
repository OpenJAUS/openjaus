/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.Array;

import java.util.Vector;

public class ArrayClass {

    private Array array;
    private String enclosingClassName;
    private int level;
    private CodeLines codeLines;
    private RecordClass recordClass;

    public ArrayClass(RecordClass recordClass, Array array, String enclosingClassName, int level) {
        this.array = array;
        this.enclosingClassName = enclosingClassName;
        this.level = level;
        this.recordClass = recordClass;
        codeLines = new CodeLines();
    }

    private void startProcess() throws RuntimeException {
        StringBuffer arrayDim = new StringBuffer();
        StringBuffer arrayFactor = new StringBuffer();
        Vector<String> param = new Vector<String>();
        int totalSize = 1;
        int preDim = 0;
        for(int i=0; i<array.getDimension().size(); i++) {
            int dimSize = (int)array.getDimension().get(i).getSize();
            totalSize = totalSize*dimSize;
            if (i>0) {
                if (i>1) {
                    arrayFactor.append("*");
                }
                arrayFactor.append(preDim);
                arrayDim.append(" + ").append(arrayFactor).append("*index").append((array.getDimension().size()-1-i));
            } else {
                arrayDim.append("index").append((array.getDimension().size()-1-i));
            }
            param.add("int index"+i);
            preDim = dimSize;
        }
        /// get field type
        FieldClass arrayField;
        if (array.getFixedField()!=null) {
            arrayField = new FixedFieldClass(recordClass, array.getFixedField(), enclosingClassName, level);
        } else if (array.getFixedLengthString()!=null) {
            arrayField = new FixedLengthStringClass(recordClass, array.getFixedLengthString(), enclosingClassName, level);
        } else if (array.getBitField()!=null) {
            arrayField = new BitFieldClass(recordClass, array.getBitField(), enclosingClassName, level);
        } else if (array.getVariableField()!=null) {
            arrayField = new VariableFieldClass(recordClass, array.getVariableField(), enclosingClassName, level);
        } else if (array.getVariableFormatField()!=null) {
            arrayField = new VariableFormatFieldClass(recordClass, array.getVariableFormatField(), enclosingClassName, level);
        } else if (array.getVariableLengthField()!=null) {
            arrayField = new VariableLengthFieldClass(recordClass, array.getVariableLengthField(), enclosingClassName, level);
        } else if (array.getVariableLengthString()!=null) {
            arrayField = new VariableLengthStringClass(recordClass, array.getVariableLengthString(), enclosingClassName, level);
        } else {
            throw new RuntimeException("Invalid Array Specification: unknown or no field definition");
        }
        String newArrayFieldClassName = enclosingClassName +"::"+arrayField.getShortClassName();
        if (!recordClass.getDefinedClassList().contains(newArrayFieldClassName)) {
            codeLines.add(arrayField.getCodeLines(CodeGen.WITH_WRAPPER_CLASS));
            recordClass.getDefinedClassList().add(newArrayFieldClassName);
        }
        codeLines.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(newArrayFieldClassName, getArrayName()+"["+totalSize+"]", false));
        codeLines.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(newArrayFieldClassName, "*get", getArrayName(), param));
        Vector<String> aGetMethodCode = new Vector<String>();
        aGetMethodCode.add("int index = "+arrayDim+";");
        aGetMethodCode.add(CodeGen.getVariableName(getArrayName()+"[index]") + ".setParent(this);");
        aGetMethodCode.add("return &"+ CodeGen.getVariableName(getArrayName()+"[index]") +";");
        codeLines.methodCodes.addAll(CodeGen.createMethodDefinition(newArrayFieldClassName, "*"+ enclosingClassName +"::get", getArrayName(), param ,aGetMethodCode));

        String tab = "";
        if (recordClass.hasPresenceVector() && array.isOptional()) {
            codeLines.encoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            codeLines.decoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            tab = "    ";
        }
        codeLines.encoderLines.add(tab+"for (int i=0; i<"+totalSize+"; i++) {");
        codeLines.encoderLines.add(tab+"    "+CodeGen.getVariableName(getArrayName())+"[i].encode(bytes, pos);");
        codeLines.encoderLines.add(tab+"}");

        codeLines.decoderLines.add(tab+"for (int i=0; i<"+totalSize+"; i++) {");
        codeLines.decoderLines.add(tab+"    "+CodeGen.getVariableName(getArrayName())+"[i].decode(bytes, pos);");
        codeLines.decoderLines.add(tab+"}");

        if (recordClass.hasPresenceVector() && array.isOptional()) {
            codeLines.encoderLines.add("}");
            codeLines.decoderLines.add("}");
        }
    }

    public CodeLines getCodeLines() {
        startProcess();
        return codeLines;
    }

    public String getArrayName() {
        return CodeGen.upperCaseFirstLetter(array.getName());
    }
}