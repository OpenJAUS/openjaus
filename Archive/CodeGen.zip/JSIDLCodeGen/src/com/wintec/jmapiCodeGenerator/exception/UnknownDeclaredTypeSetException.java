/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator.exception;

/**
 * Thrown to indicate that the program can not locate the definitions of the declared type elements in the message definitions.
 *
 * @author Jaehoon Lee
 * @version 6/8/2007
 */
public class UnknownDeclaredTypeSetException extends RuntimeException {
    public UnknownDeclaredTypeSetException() {
    }

    /**
     * @param s the detailed message
     */
    public UnknownDeclaredTypeSetException(String s) {
        super(s);
    }
}
