/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator.exception;

/**
 * Thrown to indicate that a program has attempted to create a message and its sub-elements without the valid xml binding
 * objects. It is also thrown when the structure of a message is invalid.
 *
 * @author Jaehoon Lee
 * @version 6/8/2007
 */
public class MessageConstructionException extends RuntimeException {
    public MessageConstructionException() {
    }

    /**
     * @param s the detailed message
     */
    public MessageConstructionException(String s) {
        super(s);
    }
}
