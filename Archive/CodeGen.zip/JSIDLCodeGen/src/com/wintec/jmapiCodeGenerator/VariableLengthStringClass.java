/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.VariableLengthString;

import java.util.Vector;

public class VariableLengthStringClass extends FieldClass {

    private VariableLengthString variableLengthString;
    private String enclosingClassName;
    private int level;
    private boolean useWrapperClass;
    private RecordClass recordClass;

    public VariableLengthStringClass(RecordClass recordClass, VariableLengthString variableLengthString, String enclosingClassName, int level) {
        this.variableLengthString = variableLengthString;
        this.enclosingClassName = enclosingClassName;
        this.level = level;
        this.recordClass = recordClass;
    }

    private CodeLines createCodes() throws RuntimeException {
        CodeLines codes = new CodeLines();
        /// getting length type
        String lengthType = CodeGen.getVariableType(variableLengthString.getCountField().getFieldTypeUnsigned());

        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(lengthType, getShortClassName()+"Length", false));
        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("char", getShortClassName(), true));

        codes.constructorLines.add(CodeGen.getVariableName(getShortClassName()+"Length")+" = 0;");
        codes.constructorLines.add(CodeGen.getVariableName(getShortClassName())+" = NULL;");
        codes.destructorLines.add("delete "+CodeGen.getVariableName(getShortClassName())+";");

        String tab = "";
        if (recordClass.hasPresenceVector() && variableLengthString.isOptional()) {
            tab = "    ";
            if (useWrapperClass) {
                codes.encoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
                codes.decoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            } else {
                codes.encoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
                codes.decoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            }
        }
        codes.encoderLines.add(tab+lengthType+" "+CodeGen.getVariableName(getShortClassName()+"Temp")+";");
        codes.encoderLines.add(tab+CodeGen.getVariableName(getShortClassName()+"Temp")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName()+"Length")+");");
        codes.encoderLines.add(tab+"memcpy(bytes+pos, &"+CodeGen.getVariableName(getShortClassName()+"Temp")+", sizeof("+lengthType+"));");
        codes.encoderLines.add(tab+"pos += sizeof("+lengthType+");");

        codes.decoderLines.add(tab+lengthType+" "+CodeGen.getVariableName(getShortClassName()+"Temp")+";");
        codes.decoderLines.add(tab+"memcpy(&"+CodeGen.getVariableName(getShortClassName()+"Temp")+", bytes+pos, sizeof("+lengthType+"));");
        codes.decoderLines.add(tab+CodeGen.getVariableName(getShortClassName()+"Length")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName()+"Temp")+");");
        codes.decoderLines.add(tab+"pos += sizeof("+lengthType+");");

        codes.encoderLines.add(tab+"memcpy(bytes+pos, "+CodeGen.getVariableName(getShortClassName())+", "+CodeGen.getVariableName(getShortClassName()+"Length")+");");
        codes.encoderLines.add(tab+"pos += "+CodeGen.getVariableName(getShortClassName()+"Length")+";");

        codes.decoderLines.add(tab+CodeGen.getVariableName(getShortClassName())+" = new char["+CodeGen.getVariableName(getShortClassName()+"Length")+"];");
        codes.decoderLines.add(tab+"memcpy("+CodeGen.getVariableName(getShortClassName())+", bytes+pos, "+CodeGen.getVariableName(getShortClassName()+"Length")+");");
        codes.decoderLines.add(tab+"pos += "+CodeGen.getVariableName(getShortClassName()+"Length")+";");

        if (recordClass.hasPresenceVector() && variableLengthString.isOptional()) {
            codes.encoderLines.add("}");
            codes.decoderLines.add("}"); 
        }

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(lengthType, "get", getShortClassName()+"Length", null));
        Vector<String> vlsLengthGetMethodCode = new Vector<String>();
        vlsLengthGetMethodCode.add("return "+ CodeGen.getVariableName(getShortClassName()+"Length") + ";");
        codes.methodCodes.addAll(CodeGen.createMethodDefinition(lengthType, getLongClassName()+"::get", getShortClassName()+"Length", null,vlsLengthGetMethodCode));

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("char", "*get", getShortClassName(), null));
        Vector<String> vlsGetMethodCode = new Vector<String>();
        vlsGetMethodCode.add("return "+ CodeGen.getVariableName(getShortClassName()) + ";");
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("char", "*"+getLongClassName()+"::get", getShortClassName(), null,vlsGetMethodCode));

        Vector<String> vlsSetMethodParam = new Vector<String>();
        vlsSetMethodParam.add("char *value");
        //vlsSetMethodParam.add(lengthType+" length");
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "set", getShortClassName(), vlsSetMethodParam));

        Vector<String> vlsSetMethodCode = new Vector<String>();
        vlsSetMethodCode.add(lengthType + " length = strlen(value);");
        vlsSetMethodCode.add(CodeGen.getVariableName(getShortClassName()+"Length")+ " = length;");
        vlsSetMethodCode.add(CodeGen.getVariableName(getShortClassName())+ " = new char[length];");
        vlsSetMethodCode.add("for("+lengthType+" i=0; i<length; i++) {");
        vlsSetMethodCode.add("    "+CodeGen.getVariableName(getShortClassName())+"[i] = value[i];");
        vlsSetMethodCode.add("}");
        if (recordClass.hasPresenceVector() && variableLengthString.isOptional()) {
            if (useWrapperClass)
                vlsSetMethodCode.add(CodeGen.getVariableName("Parent")+"->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
            else
                vlsSetMethodCode.add("setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
        }
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::set", getShortClassName(), vlsSetMethodParam,vlsSetMethodCode));


        if (useWrapperClass) {
            /// adding encode/decode methods
            Vector<String> param = new Vector<String>();
            param.add("unsigned char *bytes");
            param.add("int &pos");

            Vector<String> param2 = new Vector<String>();
            param2.add("unsigned char *bytes");
            param2.add("int &pos");

            /// class encoder
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "encode", null, param));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::encode", null, param, codes.encoderLines));

            /// class decoder
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "decode", null, param2));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::decode", null, param2, codes.decoderLines));

            return getWrapperClass(level, enclosingClassName, codes);
        }
		return codes;
    }

    public CodeLines getCodeLines(boolean useWrapperClass) {
        this.useWrapperClass = useWrapperClass;
        if (useWrapperClass) {
            this.level = level + 1;
        }
        return createCodes();
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(variableLengthString.getName());
    }

    public String getLongClassName() {
        if (useWrapperClass) {
            return enclosingClassName+"::"+getShortClassName();
        }
		return enclosingClassName;
    }
}
