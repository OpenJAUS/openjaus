/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.VariableField;
import com.wintec.jmapiCodeGenerator.binding.TypeAndUnitsEnum;

import java.util.Vector;

public class VariableFieldClass extends FieldClass {

    private VariableField variableField;
    private String enclosingClassName;
    private int level;
    private RecordClass recordClass;

    public VariableFieldClass(RecordClass recordClass, VariableField variableField, String enclosingClassName, int level) throws RuntimeException {
        this.variableField = variableField;
        String enclosingShortClassName = enclosingClassName.substring(enclosingClassName.lastIndexOf("::")+2);
        if (enclosingShortClassName.equalsIgnoreCase(getShortClassName())) {
            throw new RuntimeException(getShortClassName()+ " : a nested element cannot have the same name as the immediately enclosing element.");
        }
        this.enclosingClassName = enclosingClassName;
        this.level = level + 1;
        this.recordClass = recordClass;
    }

    private CodeLines createCodes() throws RuntimeException {
        CodeLines codes = new CodeLines();

        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("int", "Index", false));

        String tab = "";
        if (recordClass.hasPresenceVector() && variableField.isOptional()) {
            codes.encoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            codes.decoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            tab = "    ";
        }
        codes.encoderLines.add(tab+"jUnsignedByte indexTemp;");
        codes.encoderLines.add(tab+"indexTemp = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName("Index")+");");
        codes.encoderLines.add(tab+"memcpy(bytes+pos, &indexTemp, sizeof(indexTemp));");
        codes.encoderLines.add(tab+"pos += sizeof(indexTemp);");

        codes.decoderLines.add(tab+"jUnsignedByte indexTemp;");
        codes.decoderLines.add(tab+"memcpy(&indexTemp, bytes+pos, sizeof(indexTemp));");
        codes.decoderLines.add(tab+CodeGen.getVariableName("Index")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness(indexTemp);");
        codes.decoderLines.add(tab+"pos += sizeof(indexTemp);");

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("int", "get", "Index", null));
        Vector<String> vfGetIndexMethodCode = new Vector<String>();
        vfGetIndexMethodCode.add("return "+ CodeGen.getVariableName("Index") + ";");
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName() +"::get", "Index", null, vfGetIndexMethodCode));

        codes.protectedAttributes.add(CodeGen.tabs(level)+"union {");
        for(TypeAndUnitsEnum taue : variableField.getTypeAndUnitsField().getTypeAndUnitsEnum()) {
            int index = taue.getIndex();
            String teType = CodeGen.getVariableType(taue.getFieldType());
            String units = taue.getFieldUnits();
            String variableName = getCamelBackName(new String[]{teType,"As",units});
            codes.protectedAttributes.add(CodeGen.tabs(level+1)+CodeGen.createVariableDeclaration(teType, variableName, false));

            codes.encoderLines.add(tab+"if ("+CodeGen.getVariableName("Index")+" == "+index+") {");
            codes.encoderLines.add(tab+"    "+teType+" tempValue;");
            codes.encoderLines.add(tab+"    tempValue = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(variableName)+");");
            codes.encoderLines.add(tab+"    memcpy(bytes+pos, &tempValue, sizeof("+teType+"));");
            codes.encoderLines.add(tab+"    pos += sizeof("+teType+");");
            codes.encoderLines.add(tab+"}");

            codes.decoderLines.add(tab+"if ("+CodeGen.getVariableName("Index")+" == "+index+") {");
            codes.decoderLines.add(tab+"    "+teType+" tempValue;");
            codes.decoderLines.add(tab+"    memcpy(&tempValue, bytes+pos, sizeof("+teType+"));");
            codes.decoderLines.add(tab+"    "+CodeGen.getVariableName(variableName)+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness(tempValue);");
            codes.decoderLines.add(tab+"    pos += sizeof("+teType+");");
            codes.decoderLines.add(tab+"}");

            //Vector<String> elseCode = new Vector<String>();
            //elseCode.add("throw \"Invalid input value.\";");

            if (taue.getScaleRange()!=null) {
                /// scaled integer (float to integer and integer to float conversion required)

                Vector<String> vfGetMethodCode = new Vector<String>();
                vfGetMethodCode.add("double realValue;");
                vfGetMethodCode.addAll(CodeGen.getIntegerToFloatConvCode(taue.getScaleRange(), taue.getFieldType(), CodeGen.getVariableName(variableName), "realValue"));
                vfGetMethodCode.add("return realValue;");

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("double", "get", variableName, null));
                codes.methodCodes.addAll(CodeGen.createMethodDefinition("double", getLongClassName()+"::get", variableName, null, vfGetMethodCode));

                Vector<String> vfSetMethodParam = new Vector<String>();
                vfSetMethodParam.add("double value");

                Vector<String> setCode = new Vector<String>();
                setCode.addAll(CodeGen.getFloatToIntegerConvCode(taue.getScaleRange(), taue.getFieldType(), "value", CodeGen.getVariableName(variableName)));
                if (recordClass.hasPresenceVector() && variableField.isOptional()) setCode.add(CodeGen.getVariableName("Parent")+"->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
                setCode.add("return 0;");

                Vector<String> vfSetMethodCode = new Vector<String>();
                vfSetMethodCode.addAll(CodeGen.getValidationWrapper(taue.getScaleRange(), "value", setCode, null));
                vfSetMethodCode.add("return 1;");

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("int", "set", variableName, vfSetMethodParam));
                codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName()+"::set", variableName, vfSetMethodParam, vfSetMethodCode));
            } else {
                /// normal integer value
                Vector<String> vfGetMethodCode = new Vector<String>();
                vfGetMethodCode.add("return "+ CodeGen.getVariableName(variableName) + ";");

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(teType, "get", variableName, null));
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(teType, getLongClassName()+"::get", variableName, null, vfGetMethodCode));

                Vector<String> vfSetMethodParam = new Vector<String>();
                vfSetMethodParam.add(teType+" value");

                Vector<String> setCode = new Vector<String>();
                setCode.add(CodeGen.getVariableName(variableName)+" = value;");
                setCode.add(CodeGen.getVariableName("Index")+" = "+index+";");
                if (recordClass.hasPresenceVector() && variableField.isOptional()) setCode.add(CodeGen.getVariableName("Parent")+"->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
                setCode.add("return 0;");
                
                Vector<String> vfSetMethodCode = new Vector<String>();
                if (taue.getValueSet()!=null) {
                    /// set method with validation
                    vfSetMethodCode.addAll(CodeGen.getValidationWrapper(taue.getValueSet(), "value", setCode, null));
                    vfSetMethodCode.add("return 1;");
                } else {
                    /// set method without validation
                    vfSetMethodCode.addAll(setCode);
                }
                codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName()+"::set", variableName, vfSetMethodParam, vfSetMethodCode));
                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("int", "set", variableName, vfSetMethodParam));
            }
        }
        codes.protectedAttributes.add(CodeGen.tabs(level)+"};");

        if (recordClass.hasPresenceVector() && variableField.isOptional()) {
            codes.encoderLines.add("}");
            codes.decoderLines.add("}");
        }

        /// adding encode/decode methods
        Vector<String> param = new Vector<String>();
        param.add("unsigned char *bytes");
        param.add("int &pos");

        Vector<String> param2 = new Vector<String>();
        param2.add("unsigned char *bytes");
        param2.add("int &pos");

        /// class encoder
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "encode", null, param));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::encode", null, param, codes.encoderLines));

        /// class decoder
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "decode", null, param2));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::decode", null, param2, codes.decoderLines));

        return getWrapperClass(level, enclosingClassName, codes);
    }

    public CodeLines getCodeLines(boolean dummy) {
        return createCodes();
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(variableField.getName());
    }

    public String getLongClassName() {
        return enclosingClassName+"::"+getShortClassName();
    }

    private String getCamelBackName(String[] names) {
        StringBuffer sb = new StringBuffer();
        for(String name: names) {
            name = name.replaceAll(" ","");
            if (name.length()>=2) {
                sb.append(CodeGen.upperCaseFirstLetter(name));
            } else {
                sb.append(name.toUpperCase());
            }
        }
        return sb.toString();
    }

}
