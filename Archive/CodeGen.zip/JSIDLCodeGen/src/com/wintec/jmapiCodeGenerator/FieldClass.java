/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import java.util.Vector;

public abstract class FieldClass {
    public abstract CodeLines getCodeLines(boolean useWrapperClass);
    public abstract String getShortClassName();
    public abstract String getLongClassName();

    protected CodeLines getWrapperClass(int level, String enclosingClassName, CodeLines codes) throws RuntimeException {

        String enclosingShortClassName = enclosingClassName.substring(enclosingClassName.lastIndexOf("::")+2);
        if (enclosingShortClassName.equalsIgnoreCase(getShortClassName())) {
            throw new RuntimeException(getShortClassName()+ " : a nested element cannot have the same name as the immediately enclosing element.");
        }

        CodeLines codeLines = new CodeLines();

        codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"class "+getShortClassName()+" {");
        if (codes.classDefinitions.size()>0) {
            codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  public:");
            codeLines.classDefinitions.addAll(codes.classDefinitions);
        }
        if (codes.protectedAttributes.size()>0 || codes.protectedMethods.size()>0) {
            codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  private:");
            codeLines.classDefinitions.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(enclosingClassName, "Parent", true));
            codeLines.classDefinitions.addAll(codes.protectedAttributes);
            codeLines.classDefinitions.addAll(codes.protectedMethods);
        }
        codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  public:");
        codeLines.classDefinitions.addAll(codes.publicAttributes);
        if (!codes.constructorLines.isEmpty()) {
            codeLines.classDefinitions.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, null, getShortClassName(), null));
            codeLines.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName()+"::"+getShortClassName(), null, null,
                codes.constructorLines));
        }
        if (!codes.destructorLines.isEmpty()) {
            codeLines.classDefinitions.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, "~", getShortClassName(), null));
            codeLines.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName()+"::~", getShortClassName(), null,
                codes.destructorLines));
        }
        Vector<String> setParam = new Vector<String>();
        setParam.add(enclosingClassName+" *value");

        Vector<String> setCode = new Vector<String>();
        setCode.add(CodeGen.getVariableName("Parent")+" = value;");

        codeLines.classDefinitions.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "set", "Parent", setParam));
        codeLines.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::set", "Parent", setParam, setCode));

        codeLines.classDefinitions.addAll(codes.publicMethods);
        codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"};");
        codeLines.methodCodes.addAll(codes.methodCodes);
        return codeLines;
    }
}
