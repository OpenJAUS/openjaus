/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import java.util.Vector;

public class CodeLines {

    public Vector<String> classDefinitions;
    public Vector<String> publicAttributes;
    public Vector<String> publicMethods;
    public Vector<String> protectedAttributes;
    public Vector<String> protectedMethods;
    public Vector<String> methodCodes;
    public Vector<String> constructorLines;
    public Vector<String> destructorLines;
    public Vector<String> encoderLines;
    public Vector<String> decoderLines;


    public CodeLines() {
        classDefinitions = new Vector<String>();
        publicAttributes = new Vector<String>();
        publicMethods = new Vector<String>();
        protectedAttributes = new Vector<String>();
        protectedMethods = new Vector<String>();
        methodCodes = new Vector<String>();
        constructorLines = new Vector<String>();
        destructorLines = new Vector<String>();
        encoderLines = new Vector<String>();
        decoderLines = new Vector<String>();
    }

    public void add(CodeLines codes) {
        classDefinitions.addAll(codes.classDefinitions);
        protectedAttributes.addAll(codes.protectedAttributes);
        protectedMethods.addAll(codes.protectedMethods);
        publicAttributes.addAll(codes.publicAttributes);
        publicMethods.addAll(codes.publicMethods);
        methodCodes.addAll(codes.methodCodes);
        constructorLines.addAll(codes.constructorLines);
        destructorLines.addAll(codes.destructorLines);
        encoderLines.addAll(codes.encoderLines);
        decoderLines.addAll(codes.decoderLines);
    }

    public String getClassDefinitionString() {
        StringBuffer sb = new StringBuffer();
        for(String line: classDefinitions) {
            sb.append(line).append(CodeGen.LINE_END);
        }
        return sb.toString();
    }

    public String getPublicAttributeString() {
        StringBuffer sb = new StringBuffer();
        for(String line: publicAttributes) {
            sb.append(line).append(CodeGen.LINE_END);
        }
        return sb.toString();
    }

    public String getPublicMethodString() {
        StringBuffer sb = new StringBuffer();
        for(String line: publicMethods) {
            sb.append(line).append(CodeGen.LINE_END);
        }
        return sb.toString();
    }

    public String getProtectedAttributeString() {
        StringBuffer sb = new StringBuffer();
        for(String line: protectedAttributes) {
            sb.append(line).append(CodeGen.LINE_END);
        }
        return sb.toString();
    }

    public String getProtectedMethodString() {
        StringBuffer sb = new StringBuffer();
        for(String line: protectedMethods) {
            sb.append(line).append(CodeGen.LINE_END);
        }
        return sb.toString();
    }

    public String getMethodCodeString() {
        StringBuffer sb = new StringBuffer();
        for(String line:methodCodes) {
            sb.append(line).append(CodeGen.LINE_END);
        }
        return sb.toString();
    }

    public String getWrapperClassCode(String tab, String className, String baseClassName) {
        StringBuffer sb = new StringBuffer();
        sb.append(tab).append("class ").append(className);
        if (baseClassName!=null) sb.append(" : ").append(baseClassName);
        sb.append(" {").append(CodeGen.LINE_END);

        if (!classDefinitions.isEmpty()) {
            sb.append(tab).append("public:").append(CodeGen.LINE_END);
            sb.append(getClassDefinitionString());
        }
        if (!protectedAttributes.isEmpty() || !protectedMethods.isEmpty()) {
            sb.append(tab).append("protected:").append(CodeGen.LINE_END);
            sb.append(getProtectedAttributeString());
            sb.append(getProtectedMethodString());
        }
        if (!publicAttributes.isEmpty() || !publicMethods.isEmpty()) {
            sb.append(tab).append("public:").append(CodeGen.LINE_END);
            sb.append(getPublicAttributeString());
            sb.append(getPublicMethodString());
        }
        sb.append(tab).append("};").append(CodeGen.LINE_END);
        return sb.toString();
    }
}
