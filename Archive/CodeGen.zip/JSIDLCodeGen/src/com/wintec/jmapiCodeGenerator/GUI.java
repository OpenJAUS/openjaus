/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

public class GUI extends JFrame implements ActionListener {

    private JButton genButton;
    private JList declaredTypeSetList;
    private DefaultListModel declaredTypeSetListModel;
    private JList serviceDefList;
    private DefaultListModel serviceDefListModel;
    private JTextField outputDir;
    private JProgressBar progressBar;
    private JTextArea progressBox;
    private JScrollPane progressScroll;
    private CodeGen cg;
    
    private static final long serialVersionUID = 7526471155622776147L;

    public GUI() {
        setTitle("JSIDL C++ Code Generator");
        setLayout(new MigLayout("fillx"));
        declaredTypeSetListModel = new DefaultListModel();
        declaredTypeSetList = new JList(declaredTypeSetListModel);
        JScrollPane dtsScroll = new JScrollPane(declaredTypeSetList);

        serviceDefListModel = new DefaultListModel();
        serviceDefList = new JList(serviceDefListModel);
        JScrollPane sdScroll = new JScrollPane(serviceDefList);

        JButton addDTSButton = new JButton("Add Declared Type Set");
        addDTSButton.addActionListener(this);
        JButton removeDTSButton = new JButton("Remove Declared Type Set");
        removeDTSButton.addActionListener(this);

        JButton addSDButton = new JButton("Add Service Definition");
        addSDButton.addActionListener(this);
        JButton removeSDButton = new JButton("Remove Service Definition");
        removeSDButton.addActionListener(this);

        //outputDir = new JTextField(System.getProperty("user.dir"));
        outputDir = new JTextField("/root/workspace/TestComponent");
        JButton outputDirButton = new JButton("Change");
        outputDirButton.addActionListener(this);

        genButton = new JButton("Generate");
        genButton.addActionListener(this);
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(this);

        progressBox = new JTextArea();
        progressScroll = new JScrollPane(progressBox);
        progressScroll.setPreferredSize(new Dimension(640, 100));
        progressBar = new JProgressBar();

        getContentPane().add(new JLabel("Declared Type Set Files"), "growx, span, wrap");
        getContentPane().add(dtsScroll, "span, growx, wrap");
        getContentPane().add(addDTSButton, "growx");
        getContentPane().add(removeDTSButton, "growx, wrap");

        getContentPane().add(new JSeparator(), "growx, span, wrap");

        getContentPane().add(new JLabel("Service Definition Files"), "growx, span, wrap");
        getContentPane().add(sdScroll, "span, growx, wrap");
        getContentPane().add(addSDButton, "growx");
        getContentPane().add(removeSDButton, "growx,  wrap");

        getContentPane().add(new JSeparator(), "growx, span, wrap");

        getContentPane().add(new JLabel("Target Directory"), "growx, span, wrap");
        getContentPane().add(outputDir, "span, growx");
        getContentPane().add(outputDirButton, "span, align right, wrap");

        getContentPane().add(new JSeparator(), "growx, span, wrap");

        getContentPane().add(progressScroll, "span, growx, wrap");
        getContentPane().add(progressBar, "span, growx, wrap");

        getContentPane().add(genButton, "growx");
        getContentPane().add(closeButton, "growx, wrap");

        getContentPane().add(new JLabel("Copyright (C) 2007  WINTEC, Inc. All Rights Reserved."),"align center, span");

        addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e) {
                dispose();
                System.exit(0);
            }
        });

        setPreferredSize(new Dimension(640,600));
        pack();
        setVisible(true);
    }

    private void startGen() {
        if (cg==null || !cg.isAlive()) {
            cg = new CodeGen(this);
            cg.start();
        } else {
            JOptionPane.showMessageDialog(this, "Code generation is in progress. Please wait until it ends.");
        }
    }

    public static void main(String argv[]) {
        new GUI();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getActionCommand().equalsIgnoreCase("Generate")) {
            if (serviceDefListModel.getSize()>0) {
                startGen();
            } else {
                JOptionPane.showMessageDialog(this, "Please add a Service Definition XML file.");
            }
        }
        if (e.getActionCommand().equalsIgnoreCase("Close")) {
            System.exit(0);
        }

        if (e.getActionCommand().equalsIgnoreCase("Cancel")) {
            cg.setCancel();
        }

        if (e.getActionCommand().equalsIgnoreCase("Add Declared Type Set")) {
            if (cg==null || !cg.isAlive()) {
                openFileSelectionDialog(declaredTypeSetListModel);
            }
        }
        if (e.getActionCommand().equalsIgnoreCase("Remove Declared Type Set")) {
            if (cg==null || !cg.isAlive()) {
                if (declaredTypeSetList.getSelectedIndex()>=0) {
                    declaredTypeSetListModel.remove(declaredTypeSetList.getSelectedIndex());
                } else {
                    JOptionPane.showMessageDialog(this, "Please select a file first.");
                }
            }
        }
        if (e.getActionCommand().equalsIgnoreCase("Add Service Definition")) {
            if (cg==null || !cg.isAlive()) {
                openFileSelectionDialog(serviceDefListModel);
            }
        }
        if (e.getActionCommand().equalsIgnoreCase("Remove Service Definition")) {
            if (cg==null || !cg.isAlive()) {
                if (serviceDefList.getSelectedIndex()>=0) {
                    serviceDefListModel.remove(serviceDefList.getSelectedIndex());
                } else {
                    JOptionPane.showMessageDialog(this, "Please select a file first.");
                }
            }
        }
        if (e.getActionCommand().equalsIgnoreCase("Change")) {
            if (cg==null || !cg.isAlive()) {
                openDirSelectionDialog(outputDir);
            }
        }
    }

    public void openFileSelectionDialog(DefaultListModel listModel) {
        JFileChooser chooser = new JFileChooser(System.getProperty("user.dir")+"/examples");
        FileNameExtensionFilter filter = new FileNameExtensionFilter("XML Documents", "xml");
        chooser.setFileFilter(filter);
        chooser.setMultiSelectionEnabled(true);
        int returnVal = chooser.showOpenDialog(this);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            File[] selectedFiles = chooser.getSelectedFiles();
            for (File selectedFile:selectedFiles) {
                listModel.addElement(selectedFile);
            }
        }
    }

    public void openDirSelectionDialog(JTextField textField) {
        JFileChooser chooser = new JFileChooser(System.getProperty("user.dir"));
        chooser.setMultiSelectionEnabled(false);
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int returnVal = chooser.showOpenDialog(this);
        if(returnVal == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chooser.getSelectedFile();
            textField.setText(selectedFile.getPath());
        }
    }

    public JButton getGenButton() {
        return genButton;
    }

    public DefaultListModel getDeclaredTypeSetListModel() {
        return declaredTypeSetListModel;
    }

    public DefaultListModel getServiceDefListModel() {
        return serviceDefListModel;
    }

    public String getTargetDirectory() {
        return outputDir.getText();
    }

    public JProgressBar getProgressBar(){
        return progressBar;
    }

    public JTextArea getProgressBox(){
        return progressBox;
    }

    public JScrollBar getProgressBoxVerticalScrollBar() {
        return progressScroll.getVerticalScrollBar();    
    }
}
