/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.FixedLengthString;

import java.util.Vector;

public class FixedLengthStringClass extends FieldClass {

    private FixedLengthString fixedLengthString;
    private String enclosingClassName;
    private int level;
    private boolean useWrapperClass;
    private RecordClass recordClass;

    public FixedLengthStringClass(RecordClass recordClass, FixedLengthString fixedLengthString, String enclosingClassName, int level) {
        this.fixedLengthString = fixedLengthString;
        this.enclosingClassName = enclosingClassName;
        this.level = level;
        this.recordClass = recordClass;
    }

    private CodeLines createCodes() throws RuntimeException {
        CodeLines codes = new CodeLines();
        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("char", getShortClassName()+"["+fixedLengthString.getStringLength()+"]", false));

        codes.constructorLines.add("for (int i=0; i<"+fixedLengthString.getStringLength()+"; i++) {");
        codes.constructorLines.add("    "+CodeGen.getVariableName(getShortClassName())+"[i] = 0;");
        codes.constructorLines.add("}");

        String tab = "";
        if (recordClass.hasPresenceVector() && fixedLengthString.isOptional()) {
            tab = "    ";
            if (useWrapperClass) {
                codes.encoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
                codes.decoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            } else {
                codes.encoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
                codes.decoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            }
        }
        codes.encoderLines.add(tab+"memcpy(bytes+pos, "+CodeGen.getVariableName(getShortClassName())+", "+fixedLengthString.getStringLength()+");");
        codes.encoderLines.add(tab+"pos += "+fixedLengthString.getStringLength()+";");

        codes.decoderLines.add(tab+"memcpy("+CodeGen.getVariableName(getShortClassName())+", bytes+pos, "+fixedLengthString.getStringLength()+");");
        codes.decoderLines.add(tab+"pos += "+fixedLengthString.getStringLength()+";");

        if (recordClass.hasPresenceVector() && fixedLengthString.isOptional()) {
            codes.encoderLines.add("}");
            codes.decoderLines.add("}");
        }

        Vector<String> flsGetMethodCode = new Vector<String>();
        flsGetMethodCode.add("return "+ CodeGen.getVariableName(getShortClassName()) + ";");

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("char", "*get", getShortClassName(), null));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("char", "*"+getLongClassName()+"::get", getShortClassName(), null,flsGetMethodCode));

        Vector<String> flsSetMethodParam = new Vector<String>();
        flsSetMethodParam.add("char *value");

        Vector<String> flsSetMethodCode = new Vector<String>();
        flsSetMethodCode.add("int length = strlen(value);");
        flsSetMethodCode.add("if (length > "+fixedLengthString.getStringLength()+") length = "+fixedLengthString.getStringLength()+";");
        flsSetMethodCode.add("for (int i=0; i<length; i++) {");
        flsSetMethodCode.add("    "+CodeGen.getVariableName(getShortClassName())+"[i] = value[i];");
        flsSetMethodCode.add("}");
        if (recordClass.hasPresenceVector() && fixedLengthString.isOptional()) {
            if (useWrapperClass)
                flsSetMethodCode.add(CodeGen.getVariableName("Parent")+"->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
            else
                flsSetMethodCode.add("setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
        }

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "set", getShortClassName(), flsSetMethodParam));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::set", getShortClassName(), flsSetMethodParam, flsSetMethodCode));

        if (useWrapperClass) {
            /// adding encode/decode methods
            Vector<String> param = new Vector<String>();
            param.add("unsigned char *bytes");
            param.add("int &pos");

            Vector<String> param2 = new Vector<String>();
            param2.add("unsigned char *bytes");
            param2.add("int &pos");

            /// class encoder
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "encode", null, param));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::encode", null, param, codes.encoderLines));

            /// class decoder
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "decode", null, param2));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::decode", null, param2, codes.decoderLines));

            return getWrapperClass(level, enclosingClassName, codes);
        }
		return codes;
    }

    public CodeLines getCodeLines(boolean useWrapperClass) {
        this.useWrapperClass = useWrapperClass;
        if (useWrapperClass) {
            this.level = level + 1;
        }
        return createCodes();
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(fixedLengthString.getName());
    }

    public String getLongClassName() {
        if (useWrapperClass) {
            return enclosingClassName+"::"+getShortClassName();
        }
		return enclosingClassName;
    }
}
