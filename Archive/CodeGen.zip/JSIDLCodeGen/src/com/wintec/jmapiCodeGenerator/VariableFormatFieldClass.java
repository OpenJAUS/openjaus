/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.VariableFormatField;
import com.wintec.jmapiCodeGenerator.binding.FormatEnum;

import java.util.Vector;

public class VariableFormatFieldClass extends FieldClass {

    private VariableFormatField variableFormatField;
    private String enclosingClassName;
    private int level;
    private boolean useWrapperClass;
    private RecordClass recordClass;

    public VariableFormatFieldClass(RecordClass recordClass, VariableFormatField variableFormatField, String enclosingClassName, int level) {
        this.variableFormatField = variableFormatField;
        this.enclosingClassName = enclosingClassName;
        this.level = level;
        this.recordClass = recordClass;
    }

    private CodeLines createCodes() throws RuntimeException {
        CodeLines codes = new CodeLines();
        /// getting length type
        String lengthType = CodeGen.getVariableType(variableFormatField.getCountField().getFieldTypeUnsigned());

        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("jUnsignedByte", getShortClassName()+"Format", false));
        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(lengthType, getShortClassName()+"Length", false));
        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("unsigned char", getShortClassName(), true));

        /// getting format enum to validate input value
        StringBuffer validFormatEnum = new StringBuffer();
        for(int i=0; i<variableFormatField.getFormatField().getFormatEnum().size(); i++) {
            FormatEnum formatEnum = variableFormatField.getFormatField().getFormatEnum().get(i);
            String enumString = "(format=="+formatEnum.getIndex()+")";
            if (i==0) {
                codes.constructorLines.add(CodeGen.getVariableName(getShortClassName()+"Format")+" = "+formatEnum.getIndex()+";");
            } else {
                validFormatEnum.append("||");
            }
            validFormatEnum.append(enumString);
        }

        codes.constructorLines.add(CodeGen.getVariableName(getShortClassName()+"Length")+" = 0;");
        codes.constructorLines.add(CodeGen.getVariableName(getShortClassName())+" = NULL;");
        codes.destructorLines.add("delete "+CodeGen.getVariableName(getShortClassName())+";");

        String tab = "";
        if (recordClass.hasPresenceVector() && variableFormatField.isOptional()) {
            tab = "    ";
            if (useWrapperClass) {
                codes.encoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
                codes.decoderLines.add("if ("+CodeGen.getVariableName("Parent")+"->checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            } else {
                codes.encoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
                codes.decoderLines.add("if (checkPresenceVector("+ recordClass.getPresenceVectorIndex() +")) {");
            }
        }
        codes.encoderLines.add(tab+"jUnsignedByte "+CodeGen.getVariableName(getShortClassName()+"Temp")+";");
        codes.encoderLines.add(tab+CodeGen.getVariableName(getShortClassName()+"Temp")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName()+"Format")+");");
        codes.encoderLines.add(tab+"memcpy(bytes+pos, &"+CodeGen.getVariableName(getShortClassName()+"Temp")+", sizeof("+CodeGen.getVariableName(getShortClassName()+"Temp")+"));");
        codes.encoderLines.add(tab+"pos += sizeof("+CodeGen.getVariableName(getShortClassName()+"Temp")+");");

        codes.decoderLines.add(tab+"jUnsignedByte "+CodeGen.getVariableName(getShortClassName()+"Temp")+";");
        codes.decoderLines.add(tab+"memcpy(&"+CodeGen.getVariableName(getShortClassName()+"Temp")+", bytes+pos, sizeof("+CodeGen.getVariableName(getShortClassName()+"Temp")+"));");
        codes.decoderLines.add(tab+CodeGen.getVariableName(getShortClassName()+"Format")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName()+"Temp")+");");
        codes.decoderLines.add(tab+"pos += sizeof("+CodeGen.getVariableName(getShortClassName()+"Temp")+");");

        codes.encoderLines.add(tab+lengthType+" "+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+";");
        codes.encoderLines.add(tab+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName()+"Length")+");");
        codes.encoderLines.add(tab+"memcpy(bytes+pos, &"+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+", sizeof("+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+"));");
        codes.encoderLines.add(tab+"pos += sizeof("+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+");");

        codes.decoderLines.add(tab+lengthType+" "+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+";");
        codes.decoderLines.add(tab+"memcpy(&"+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+", bytes+pos, sizeof("+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+"));");
        codes.decoderLines.add(tab+CodeGen.getVariableName(getShortClassName()+"Length")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+");");
        codes.decoderLines.add(tab+"pos += sizeof("+CodeGen.getVariableName(getShortClassName()+"LengthTemp")+");");

        codes.encoderLines.add(tab+"memcpy(bytes+pos, "+CodeGen.getVariableName(getShortClassName())+", "+CodeGen.getVariableName(getShortClassName()+"Length")+");");
        codes.encoderLines.add(tab+"pos += "+CodeGen.getVariableName(getShortClassName()+"Length")+";");

        codes.decoderLines.add(tab+CodeGen.getVariableName(getShortClassName())+" = new unsigned char["+CodeGen.getVariableName(getShortClassName()+"Length")+"];");
        codes.decoderLines.add(tab+"memcpy("+CodeGen.getVariableName(getShortClassName())+", bytes+pos, "+CodeGen.getVariableName(getShortClassName()+"Length")+");");
        codes.decoderLines.add(tab+"pos += "+CodeGen.getVariableName(getShortClassName()+"Length")+";");

        if (recordClass.hasPresenceVector() && variableFormatField.isOptional()) {
            codes.encoderLines.add("}");
            codes.decoderLines.add("}");
        }

        Vector<String> vffFormatGetMethodCode = new Vector<String>();
        //vffFormatGetMethodCode.add("return ("+getShortClassName()+"Format)"+CodeGen.getVariableName(getShortClassName()+"Format")+";");
        vffFormatGetMethodCode.add("return "+CodeGen.getVariableName(getShortClassName()+"Format")+";");

        //codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(getShortClassName()+"Format", "get", getShortClassName()+"Format", null));
        //codes.methodCodes.addAll(CodeGen.createMethodDefinition(getLongClassName()+"::"+getShortClassName()+"Format", getLongClassName()+"::get", getShortClassName()+"Format", null,vffFormatGetMethodCode));
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("jUnsignedByte", "get", getShortClassName()+"Format", null));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("jUnsignedByte", getLongClassName()+"::get", getShortClassName()+"Format", null,vffFormatGetMethodCode));

        Vector<String> vffLengthGetMethodCode = new Vector<String>();
        vffLengthGetMethodCode.add("return "+ CodeGen.getVariableName(getShortClassName()+"Length") + ";");

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(lengthType, "get", getShortClassName()+"Length",null));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition(lengthType, getLongClassName()+"::get", getShortClassName()+"Length",null,vffLengthGetMethodCode));

        Vector<String> vffGetMethodCode = new Vector<String>();
        vffGetMethodCode.add("return "+ CodeGen.getVariableName(getShortClassName()) + ";");

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("unsigned char", "*get", getShortClassName(), null));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("unsigned char", "*"+getLongClassName()+"::get", getShortClassName(), null,vffGetMethodCode));

        Vector<String> vffSetMethodParam= new Vector<String>();
        //vffSetMethodParam.add(getShortClassName()+"Format format");
        vffSetMethodParam.add("jUnsignedByte format");
        vffSetMethodParam.add("unsigned char *value");
        vffSetMethodParam.add("int length");

        Vector<String> vffSetMethodCode= new Vector<String>();
        vffSetMethodCode.add("if ("+validFormatEnum+") {");
        vffSetMethodCode.add("    "+CodeGen.getVariableName(getShortClassName()+"Format")+ " = format;");
        vffSetMethodCode.add("} else {");
        vffSetMethodCode.add("    return 1;");
        vffSetMethodCode.add("}");
        vffSetMethodCode.add(CodeGen.getVariableName(getShortClassName()+"Length")+ " = length;");
        vffSetMethodCode.add(CodeGen.getVariableName(getShortClassName())+ " = new unsigned char[length];");
        vffSetMethodCode.add("for(int i=0; i<length; i++) {");
        vffSetMethodCode.add("    "+CodeGen.getVariableName(getShortClassName())+"[i] = value[i];");
        vffSetMethodCode.add("}");
        if (recordClass.hasPresenceVector() && variableFormatField.isOptional()) {
            if (useWrapperClass)
                vffSetMethodCode.add(CodeGen.getVariableName("Parent")+"->setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
            else
                vffSetMethodCode.add("setPresenceVector("+ recordClass.getPresenceVectorIndex() +");");
        }
        vffSetMethodCode.add("return 0;");

        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("int", "set", getShortClassName(), vffSetMethodParam));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("int", getLongClassName()+"::set", getShortClassName(), vffSetMethodParam,vffSetMethodCode));

        if (useWrapperClass) {
            /// adding encode/decode methods
            Vector<String> param = new Vector<String>();
            param.add("unsigned char *bytes");
            param.add("int &pos");

            Vector<String> param2 = new Vector<String>();
            param2.add("unsigned char *bytes");
            param2.add("int &pos");

            /// class encoder
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "encode", null, param));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::encode", null, param, codes.encoderLines));

            /// class decoder
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "decode", null, param2));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::decode", null, param2, codes.decoderLines));

            return getWrapperClass(level, enclosingClassName, codes);
        }
		return codes;
    }

    public CodeLines getCodeLines(boolean useWrapperClass) {
        this.useWrapperClass = useWrapperClass;
        if (useWrapperClass) {
            this.level = level + 1;
        }
        return createCodes();
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(variableFormatField.getName());
    }

    public String getLongClassName() {
        if (useWrapperClass) {
            return enclosingClassName+"::"+getShortClassName();
        }
		return enclosingClassName;
    }
}
