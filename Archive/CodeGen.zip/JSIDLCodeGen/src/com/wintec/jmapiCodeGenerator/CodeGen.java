/********************************************************************************
 Copyright (C) 2007  WINTEC, Inc.

 Sponsored by Air Force Research Laboratory, Tyndall AFB,
 The Office of Naval Research, Naval Surface Warfare Center Panama City, and
 Technical Support Working Group.

 All Rights Reserved.
 *********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.*;
import com.wintec.jmapiCodeGenerator.exception.MessageConstructionException;
import com.wintec.jmapiCodeGenerator.exception.UnknownDeclaredTypeSetException;
import com.wintec.util.TextFileHandler;

import javax.swing.*;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.SchemaFactory;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Vector;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class CodeGen extends Thread {

    public static final String ROOT_NAMESPACE = "JSIDL_V0_9";
    public static final String LINE_END = System.getProperty("line.separator");
    public static final String VARIABLE_PREFIX = "m_";
    public static final String VARIABLE_SURFIX = "";

    public static final boolean WITH_WRAPPER_CLASS = true;
    public static final boolean WITHOUT_WRAPPER_CLASS = false;

    public static String getTemplate(String templateName) {
        File template = new File("template/"+templateName);
        String templateString = null;
        try {
            templateString = TextFileHandler.getContents(template);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return templateString;
    }

    public static String getVariableType(String jsidlType) {
        if (jsidlType.equalsIgnoreCase("unsigned byte")) {
            return "jUnsignedByte";
        } else if (jsidlType.equalsIgnoreCase("unsigned short integer")) {
            return "jUnsignedShortInteger";
        } else if (jsidlType.equalsIgnoreCase("unsigned integer")) {
            return "jUnsignedInteger";
        } else if (jsidlType.equalsIgnoreCase("unsigned long integer")) {
            return "jUnsignedLongInteger";
        } else if (jsidlType.equalsIgnoreCase("byte")) {
            return "jByte";
        } else if (jsidlType.equalsIgnoreCase("short integer")) {
            return "jShortInteger";
        } else if (jsidlType.equalsIgnoreCase("integer")) {
            return "jInteger";
        } else if (jsidlType.equalsIgnoreCase("long integer")) {
            return "jLongInteger";
        } else if (jsidlType.equalsIgnoreCase("float")) {
            return "jFloat";
        } else if (jsidlType.equalsIgnoreCase("long float")) {
            return "jLongFloat";
        }
        throw new RuntimeException("!!! JSIDL unknown type !!!");
    }

    public static String tabs(int indentLevel) {
        StringBuffer tab = new StringBuffer("    ");
        for(int i=0; i<indentLevel;i++) {
            tab.append("    ");
        }
        return tab.toString();
    }

    public static String getVariableName(String name) {
        return VARIABLE_PREFIX + upperCaseFirstLetter(name) + VARIABLE_SURFIX;
    }

    public static String createVariableDeclaration(String type, String name, boolean isPointer) {
        StringBuffer sb = new StringBuffer();
        sb.append(type).append(" ");
        if (isPointer) sb.append("*");
        sb.append(getVariableName(name)).append(";");
        return sb.toString();
    }

    private static String createMethodSignature(String type, String prefix, String name, Vector<String> parameters) {
        StringBuffer sb = new StringBuffer();
        if (type!=null) sb.append(type).append(" ");
        if (prefix!=null) sb.append(prefix);
        if (name!=null) sb.append(upperCaseFirstLetter(name));
        sb.append("(");
        if (parameters!=null) {
            for(int i=0; i<parameters.size(); i++) {
                if (i>0) sb.append(", ");
                sb.append(parameters.get(i));
            }
        }
        sb.append(")");
        return sb.toString();
    }

    public static String createMethodDeclaration(String type, String prefix, String name, Vector<String> parameters) {
        return createMethodSignature(type, prefix, name, parameters)+";";
    }

    public static Vector<String> createMethodDefinition(String type, String prefix, String name, Vector<String> parameters, Vector<String> methodContents) {
        Vector<String> codeLines = new Vector<String>();
        codeLines.add(tabs(0)+createMethodSignature(type, prefix, name, parameters)+" {");
        if (methodContents!=null) {
            for(String line:methodContents) {
                codeLines.add(tabs(1)+line);
            }
        }
        codeLines.add(tabs(0)+"};");
        codeLines.add("");
        return codeLines;
    }

    public static Vector<String> getValidationWrapper(ValueSet valueSet, String inputVariableName, Vector<String> ifBlock, Vector<String> elseBlock) {
        StringBuffer sb = new StringBuffer();
        for(int i=0; i<valueSet.getValueRangeOrValueEnum().size();i++) {
            if (i>0) sb.append(" || ");
            if (valueSet.getValueRangeOrValueEnum().get(i) instanceof ValueEnum) {
                /// value enum
                ValueEnum ve = (ValueEnum) valueSet.getValueRangeOrValueEnum().get(i);
                sb.append("(").append(inputVariableName).append(" == ").append(ve.getEnumIndex()).append(")");
            } else {
                /// value range
                ValueRange vr = (ValueRange) valueSet.getValueRangeOrValueEnum().get(i);
                sb.append("(").append(inputVariableName);
                if (vr.getLowerLimitType().equalsIgnoreCase("exclusive")) sb.append(" > "); else sb.append(" >= ");
                sb.append(vr.getLowerLimit()).append(" && ").append("value");
                if (vr.getUpperLimitType().equalsIgnoreCase("exclusive")) sb.append(" < "); else sb.append(" <= ");
                sb.append(vr.getUpperLimit()).append(")");
            }
        }
        Vector<String> codes = new Vector<String>();
        codes.add("if ("+sb.toString()+") {");
        if (ifBlock!=null) {
            for(String line: ifBlock) {
                codes.add("    "+line);
            }
        }
        if (elseBlock!=null) {
            codes.add("} else {");
            for(String line: elseBlock) {
                codes.add("    "+line);
            }
        }
        codes.add("}");
        return codes;
    }

    public static Vector<String> getValidationWrapper(ScaleRange scaleRange, String inputVariableName, Vector<String> ifBlock, Vector<String> elseBlock) {
        String min = scaleRange.getRealLowerLimit();
        if (min.contains("PI")) min = min.replace("PI","3.14159265358979323846");
        if (min.contains("e")) min = min.replace("e","2.7182818284590452354");

        String max = scaleRange.getRealUpperLimit();
        if (max.contains("PI")) max = max.replace("PI","3.14159265358979323846");
        if (max.contains("e")) max = max.replace("e","2.7182818284590452354");

        Vector<String> codes = new Vector<String>();
        codes.add("if ("+inputVariableName+" >= "+min+" && "+inputVariableName+" <= "+max+") {");
        if (ifBlock!=null) {
            for(String line: ifBlock) {
                codes.add("    "+line);
            }
        }
        if (elseBlock!=null) {
            codes.add("} else {");
            for(String line: elseBlock) {
                codes.add("    "+line);
            }
        }
        codes.add("}");
        return codes;
    }

    public static Vector<String> getIntegerToFloatConvCode(ScaleRange scaleRange, String integerType, String variableName, String convertedVariableName) {
        String min = scaleRange.getRealLowerLimit();
        if (min.contains("PI")) min = min.replace("PI","3.14159265358979323846");
        if (min.contains("e")) min = min.replace("e","2.7182818284590452354");

        String max = scaleRange.getRealUpperLimit();
        if (max.contains("PI")) max = max.replace("PI","3.14159265358979323846");
        if (max.contains("e")) max = max.replace("e","2.7182818284590452354");

        Vector<String> codes = new Vector<String>();
        if (integerType.startsWith("unsigned")) {
            double scaleFactor = (Double.valueOf(max)-Double.valueOf(min))/getIntegerRange(integerType);
            double bias = Double.valueOf(min);
	        codes.add("double scaleFactor = "+scaleFactor+";");
	        codes.add("double bias = "+bias+";");
	        codes.add(convertedVariableName+" = "+variableName+" * scaleFactor + bias;");
        } else {
        	double maxPlusMinBy2 = (Double.valueOf(max) + Double.valueOf(min))/2.0;
        	double maxMinusMin = Double.valueOf(max) - Double.valueOf(min);
        	double integerRange = getIntegerRange(integerType);
	        codes.add(convertedVariableName+" = ("+variableName+" * "+maxMinusMin+") / (2 * "+integerRange+") + "+maxPlusMinBy2+";");
        }
        return codes;
    }

    public static Vector<String> getFloatToIntegerConvCode(ScaleRange scaleRange, String integerType, String variableName, String convertedVariableName) {
        String min = scaleRange.getRealLowerLimit();
        if (min.contains("PI")) min = min.replace("PI","3.14159265358979323846");
        if (min.contains("e")) min = min.replace("e","2.7182818284590452354");

        String max = scaleRange.getRealUpperLimit();
        if (max.contains("PI")) max = max.replace("PI","3.14159265358979323846");
        if (max.contains("e")) max = max.replace("e","2.7182818284590452354");

        Vector<String> codes = new Vector<String>();
        if (integerType.startsWith("unsigned")) {
            double scaleFactor = (Double.valueOf(max) - Double.valueOf(min)) / getIntegerRange(integerType);
            double bias = Double.valueOf(min);
            String integerFunction = scaleRange.getIntegerFunction();
            if (integerFunction.equalsIgnoreCase("round")) integerFunction = "";
	        codes.add("double scaleFactor = "+scaleFactor+";");
	        codes.add("double bias = "+bias+";");
	        codes.add(convertedVariableName+" = ("+getVariableType(integerType)+")"+ integerFunction+"(("+variableName+" - bias) / scaleFactor);");
        } else {
        	double maxPlusMinBy2 = (Double.valueOf(max) + Double.valueOf(min))/2.0;
        	double maxMinusMin = Double.valueOf(max) - Double.valueOf(min);
        	double integerRange = getIntegerRange(integerType);
	        codes.add(convertedVariableName+" = ("+getVariableType(integerType)+")(("+variableName+" - "+maxPlusMinBy2+") * 2 * ("+integerRange+" / "+maxMinusMin+");");
        }
	    return codes;
    }

    private static double getIntegerRange(String jsidlType) {
        if (jsidlType.equalsIgnoreCase("byte")) {
            return 127;
        } else if (jsidlType.equalsIgnoreCase("unsigned byte")) {
            return 255;
        } else if (jsidlType.equalsIgnoreCase("short integer")) {
            return 32767;
        } else if (jsidlType.equalsIgnoreCase("unsigned short integer")) {
            return 65535;
        } else if (jsidlType.equalsIgnoreCase("integer")) {
            return 2147483647L;
        } else if (jsidlType.equalsIgnoreCase("unsigned integer")) {
            return 4294967295L;
        } else if (jsidlType.equalsIgnoreCase("long integer")) {
            return 9.22337203685e18;
        } else if (jsidlType.equalsIgnoreCase("unsigned long integer")) {
            return 1.84467440737e19;
        }
        throw new RuntimeException("!!! Unknown JSIDL type : "+jsidlType);
    }

    public static int getVariableSize(String jsidlType) {
        if (jsidlType.equalsIgnoreCase("unsigned byte")||jsidlType.equalsIgnoreCase("byte")) {
            return 1;
        } else if (jsidlType.equalsIgnoreCase("unsigned short integer")||jsidlType.equalsIgnoreCase("short integer")) {
            return 2;
        } else if (jsidlType.equalsIgnoreCase("unsigned integer")||jsidlType.equalsIgnoreCase("integer")||jsidlType.equalsIgnoreCase("float")) {
            return 4;
        } else if (jsidlType.equalsIgnoreCase("unsigned long integer")||jsidlType.equalsIgnoreCase("long integer")||jsidlType.equalsIgnoreCase("long float")) {
            return 8;
        }
        throw new RuntimeException("!!! Unknown JSIDL type : "+jsidlType);
    }

    public static String upperCaseFirstLetter(String name) {
        return name.substring(0,1).toUpperCase()+name.substring(1);
    }

    private Unmarshaller unmarshaller;
    private java.util.Hashtable<String, java.util.Hashtable<String, Object>> declaredTypeSetTable;
    private java.util.Hashtable<String, String> declaredTypeSetRefTable;

    private GUI gui;
    private boolean cancelFlag;

    public CodeGen(GUI gui) {
        this.gui = gui;
        try {
            /// preprocessing items
            declaredTypeSetTable = new java.util.Hashtable<String, java.util.Hashtable<String, Object>>();
            declaredTypeSetRefTable = new java.util.Hashtable<String, String>();

            /// initializing xml unmashaller
            JAXBContext jc = JAXBContext.newInstance("com.wintec.jmapiCodeGenerator.binding");
            unmarshaller = jc.createUnmarshaller();
            unmarshaller.setSchema(SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI).newSchema(new File("schema/jsidl.xsd")));

            /// pre-processing xml files
            gui.getProgressBox().append("Start declared type set processing...\n");
            for(int i=0; i<gui.getDeclaredTypeSetListModel().getSize(); i++) {
                preprocessDeclaredTypeSetXmlFile((File)gui.getDeclaredTypeSetListModel().getElementAt(i));
            }
            resolveDeclaredTypesInDeclaredTypeSet();
            gui.getProgressBox().append("End declared type set processing...\n");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void preprocessDeclaredTypeSetXmlFile(File file) throws Exception {
        if (file != null) {
            if (file.exists()) {
                InputStream inputStream = new FileInputStream(file);
                DeclaredTypeSet b_DeclaredTypeSet = (DeclaredTypeSet) unmarshaller.unmarshal(inputStream);
                inputStream.close();
                if (b_DeclaredTypeSet != null) {
                    gui.getProgressBox().append("Processing: " + b_DeclaredTypeSet.getName()+"\n");
                    processDeclaredTypeSet(b_DeclaredTypeSet);
                }
            }
        }
    }

    private void processDeclaredTypeSet(com.wintec.jmapiCodeGenerator.binding.DeclaredTypeSet b_DeclaredTypeSet) {
        if (b_DeclaredTypeSet != null) {
            for (com.wintec.jmapiCodeGenerator.binding.DeclaredTypeSetRef b_DeclaredTypeSetRef : b_DeclaredTypeSet.getDeclaredTypeSetRef()) {
                declaredTypeSetRefTable.put(b_DeclaredTypeSet.getId() + "|" + b_DeclaredTypeSet.getVersion() + "|" + b_DeclaredTypeSetRef.getName(),
                    b_DeclaredTypeSetRef.getId() + "|" + b_DeclaredTypeSetRef.getVersion());
            }
            java.util.Hashtable<String, Object> declaredObjectList = new java.util.Hashtable<String, Object>();
            declaredTypeSetTable.put(b_DeclaredTypeSet.getId() + "|" + b_DeclaredTypeSet.getVersion(), declaredObjectList);
            if (b_DeclaredTypeSet.getRecordOrListOrArray() != null) {
                for (Object obj : b_DeclaredTypeSet.getRecordOrListOrArray()) {
                    String objName;
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.List) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.List) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.Record) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.Record) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.Array) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.Array) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.FixedField) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.FixedField) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.BitField) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.BitField) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.VariableField) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.VariableField) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.FixedLengthString) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.FixedLengthString) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.VariableLengthString) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.VariableLengthString) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.VariableLengthField) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.VariableLengthField) obj).getName();
                    } else if (obj instanceof com.wintec.jmapiCodeGenerator.binding.VariableFormatField) {
                        objName = ((com.wintec.jmapiCodeGenerator.binding.VariableFormatField) obj).getName();
                    } else {
                        throw new UnknownDeclaredTypeSetException("Invalid declared_type_set element: " + obj.getClass().getName());
                    }
                    declaredObjectList.put(objName, obj);
                }
            }
        }
    }

    private void resolveDeclaredTypesInDeclaredTypeSet() {
        /// resolve any declared types in DeclaredTypeSet
        while(true) {
            int numOfChanges = 0;
            java.util.Enumeration<String> declaredTypeSetKeys = declaredTypeSetTable.keys();
            while (declaredTypeSetKeys.hasMoreElements()) {
                String key = declaredTypeSetKeys.nextElement();
                java.util.Enumeration<Object> declaredTypeObjects = declaredTypeSetTable.get(key).elements();
                while (declaredTypeObjects.hasMoreElements()) {
                    Object obj = declaredTypeObjects.nextElement();
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.Array) {
                        numOfChanges += resolveDeclaredTypes(key, (com.wintec.jmapiCodeGenerator.binding.Array) obj);
                    }
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.Record) {
                        numOfChanges += resolveDeclaredTypes(key, (com.wintec.jmapiCodeGenerator.binding.Record) obj);
                    }
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.List) {
                        numOfChanges += resolveDeclaredTypes(key, (com.wintec.jmapiCodeGenerator.binding.List) obj);
                    }
                }
            }
            if (numOfChanges==0) break;
        }
    }

    private void resolveDeclaredTypes(String defaultDeclaredTypeSetIdVersion, com.wintec.jmapiCodeGenerator.binding.MessageDef messageDef) {
        com.wintec.jmapiCodeGenerator.binding.Body b_Body = messageDef.getBody();
        if (b_Body != null) {
            if (b_Body.getRecord() != null) {
                resolveDeclaredTypes(defaultDeclaredTypeSetIdVersion, b_Body.getRecord());
            }
            com.wintec.jmapiCodeGenerator.binding.DeclaredRecord declaredRecord = b_Body.getDeclaredRecord();
            if (declaredRecord != null) {
                com.wintec.jmapiCodeGenerator.binding.Record replacementRecord = null;
                if (declaredRecord.getDeclaredTypeSetRefName() == null) {
                    java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(defaultDeclaredTypeSetIdVersion);
                    if (declaredTypeSet != null) {
                        replacementRecord = getCopy((com.wintec.jmapiCodeGenerator.binding.Record) declaredTypeSet.get(declaredRecord.getDeclaredTypeName()), declaredRecord);
                    }
                } else {
                    String declaredTypeSetIdVersion = declaredTypeSetRefTable.get(defaultDeclaredTypeSetIdVersion + "|" + declaredRecord.getDeclaredTypeSetRefName());
                    if (declaredTypeSetIdVersion != null) {
                        java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(declaredTypeSetIdVersion);
                        if (declaredTypeSet != null) {
                        	com.wintec.jmapiCodeGenerator.binding.Record record = (com.wintec.jmapiCodeGenerator.binding.Record) declaredTypeSet.get(declaredRecord.getDeclaredTypeName());
                        	if (record!=null) {
                        		replacementRecord = getCopy(record, declaredRecord);
                        	} else {
                                throw new UnknownDeclaredTypeSetException("declared_type_set_ref_name = " + declaredRecord.getDeclaredTypeSetRefName()
                                        + "declared_type_name = " + declaredRecord.getDeclaredTypeName());
                        	}
                        }
                    }
                }
                if (replacementRecord != null) {
                    b_Body.setRecord(replacementRecord);
                    b_Body.setDeclaredRecord(null);
                } else {
                    throw new UnknownDeclaredTypeSetException("declared_type_set_ref_name = " + declaredRecord.getDeclaredTypeSetRefName()
                        + "declared_type_name = " + declaredRecord.getDeclaredTypeName());
                }
            }
            if (b_Body.getListCountAndListOrDeclaredList() != null) {
                java.util.List<Object> lists = b_Body.getListCountAndListOrDeclaredList();
                for (int i = 0; i < lists.size(); i++) {
                    Object obj = lists.get(i);
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.List) {
                        resolveDeclaredTypes(defaultDeclaredTypeSetIdVersion, (com.wintec.jmapiCodeGenerator.binding.List) obj);
                    }
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.DeclaredList) {
                        com.wintec.jmapiCodeGenerator.binding.DeclaredList declaredList = (com.wintec.jmapiCodeGenerator.binding.DeclaredList) obj;
                        com.wintec.jmapiCodeGenerator.binding.List replacementList = null;
                        if (declaredList.getDeclaredTypeSetRefName() == null) {
                            java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(defaultDeclaredTypeSetIdVersion);
                            if (declaredTypeSet != null) {
                                com.wintec.jmapiCodeGenerator.binding.List rList = (com.wintec.jmapiCodeGenerator.binding.List) declaredTypeSet.get(declaredList.getDeclaredTypeName());
                                if (rList!=null)  {
                                    replacementList = getCopy(rList, declaredList);
                                }
                            }
                        } else {
                            String declaredTypeSetIdVersion = declaredTypeSetRefTable.get(defaultDeclaredTypeSetIdVersion + "|" + declaredList.getDeclaredTypeSetRefName());
                            if (declaredTypeSetIdVersion != null) {
                                java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(declaredTypeSetIdVersion);
                                if (declaredTypeSet != null) {
                                    replacementList = getCopy((com.wintec.jmapiCodeGenerator.binding.List) declaredTypeSet.get(declaredList.getDeclaredTypeName()), declaredList);
                                }
                            }
                        }
                        if (replacementList != null) {
                            lists.remove(i);
                            lists.add(i, replacementList);
                        } else {
                            throw new UnknownDeclaredTypeSetException("declared_type_set_ref_name = " + declaredList.getDeclaredTypeSetRefName()
                                + ", declared_type_name = " + declaredList.getDeclaredTypeName());
                        }
                    }
                }
            }
        }
    }

    private int resolveDeclaredTypes(String defaultDeclaredTypeSetIdVersion, com.wintec.jmapiCodeGenerator.binding.List b_List) {
        int numOfChanges = 0;
        if (b_List != null) {
            if (b_List.getRecord() != null) {
                resolveDeclaredTypes(defaultDeclaredTypeSetIdVersion, b_List.getRecord());
            }
            com.wintec.jmapiCodeGenerator.binding.DeclaredRecord declaredRecord = b_List.getDeclaredRecord();
            if (declaredRecord != null) {
                com.wintec.jmapiCodeGenerator.binding.Record replacementRecord = null;
                if (declaredRecord.getDeclaredTypeSetRefName() == null) {
                    java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(defaultDeclaredTypeSetIdVersion);
                    if (declaredTypeSet != null) {
                        com.wintec.jmapiCodeGenerator.binding.Record rRecord = (com.wintec.jmapiCodeGenerator.binding.Record) declaredTypeSet.get(declaredRecord.getDeclaredTypeName());
                        if (rRecord!=null) {
                            replacementRecord = getCopy(rRecord, declaredRecord);
                        }
                    }
                } else {
                    String declaredTypeSetIdVersion = declaredTypeSetRefTable.get(defaultDeclaredTypeSetIdVersion + "|" + declaredRecord.getDeclaredTypeSetRefName());
                    if (declaredTypeSetIdVersion != null) {
                        java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(declaredTypeSetIdVersion);
                        if (declaredTypeSet != null) {
                            replacementRecord = getCopy((com.wintec.jmapiCodeGenerator.binding.Record) declaredTypeSet.get(declaredRecord.getDeclaredTypeName()), declaredRecord);
                        }
                    }
                }
                if (replacementRecord != null) {
                    b_List.setRecord(replacementRecord);
                    b_List.setDeclaredRecord(null);
                    numOfChanges++;
                } else {
                    throw new UnknownDeclaredTypeSetException("declared_type_set_ref_name = " + declaredRecord.getDeclaredTypeSetRefName()
                        + ", declared_type_name = " + declaredRecord.getDeclaredTypeName());
                }
            }
            if (b_List.getListCountAndListOrDeclaredList() != null) {
                java.util.List<Object> lists = b_List.getListCountAndListOrDeclaredList();
                for (int i = 0; i < lists.size(); i++) {
                    Object obj = lists.get(i);
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.List) {
                        resolveDeclaredTypes(defaultDeclaredTypeSetIdVersion, (com.wintec.jmapiCodeGenerator.binding.List) obj);
                    }
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.DeclaredList) {
                        com.wintec.jmapiCodeGenerator.binding.DeclaredList declaredList = (com.wintec.jmapiCodeGenerator.binding.DeclaredList) obj;
                        com.wintec.jmapiCodeGenerator.binding.List replacementList = null;
                        if (declaredList.getDeclaredTypeSetRefName() == null) {
                            java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(defaultDeclaredTypeSetIdVersion);
                            if (declaredTypeSet != null) {
                                replacementList = getCopy((com.wintec.jmapiCodeGenerator.binding.List) declaredTypeSet.get(declaredList.getDeclaredTypeName()), declaredList);
                            }
                        } else {
                            String declaredTypeSetIdVersion = declaredTypeSetRefTable.get(defaultDeclaredTypeSetIdVersion + "|" + declaredList.getDeclaredTypeSetRefName());
                            if (declaredTypeSetIdVersion != null) {
                                java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(declaredTypeSetIdVersion);
                                if (declaredTypeSet != null) {
                                    replacementList = getCopy((com.wintec.jmapiCodeGenerator.binding.List) declaredTypeSet.get(declaredList.getDeclaredTypeName()), declaredList);
                                }
                            }
                        }
                        if (replacementList != null) {
                            lists.remove(i);
                            lists.add(i, replacementList);
                            numOfChanges++;
                        } else {
                            throw new UnknownDeclaredTypeSetException("declared_type_set_ref_name = " + declaredList.getDeclaredTypeSetRefName()
                                + ", declared_type_name = " + declaredList.getDeclaredTypeName());
                        }
                    }
                }
            }
        }
        return numOfChanges;
    }

    private com.wintec.jmapiCodeGenerator.binding.List getCopy(com.wintec.jmapiCodeGenerator.binding.List list, com.wintec.jmapiCodeGenerator.binding.DeclaredList declaredList) {
        com.wintec.jmapiCodeGenerator.binding.List newList = new com.wintec.jmapiCodeGenerator.binding.List();
        newList.setName(declaredList.getName());
        if (declaredList.getInterpretation()!=null) {
            newList.setInterpretation(declaredList.getInterpretation());
        } else {
            newList.setInterpretation(list.getInterpretation());
        }
        newList.setRecord(list.getRecord());
        newList.setRecordCount(list.getRecordCount());
        newList.setDeclaredRecord(list.getDeclaredRecord());
        java.util.List<Object> lists = newList.getListCountAndListOrDeclaredList();
        for (Object o : list.getListCountAndListOrDeclaredList()) {
            lists.add(o);
        }
        return newList;
    }

    private com.wintec.jmapiCodeGenerator.binding.Record getCopy(com.wintec.jmapiCodeGenerator.binding.Record record, com.wintec.jmapiCodeGenerator.binding.DeclaredRecord declaredRecord) {
        com.wintec.jmapiCodeGenerator.binding.Record newRecord = new com.wintec.jmapiCodeGenerator.binding.Record();
        newRecord.setName(declaredRecord.getName());
        if (declaredRecord.getInterpretation()!=null) {
            newRecord.setInterpretation(declaredRecord.getInterpretation());
        } else {
        	newRecord.setInterpretation(record.getInterpretation());
        }
        newRecord.setPresenceVector(record.getPresenceVector());
        java.util.List<Object> fields = newRecord.getArrayOrFixedFieldOrVariableField();
        for (Object o : record.getArrayOrFixedFieldOrVariableField()) {
            fields.add(o);
        }
        return newRecord;
    }

    private Object getCopy(Object object, com.wintec.jmapiCodeGenerator.binding.DeclaredField declaredField) {
        Object newObject;
        if (object instanceof com.wintec.jmapiCodeGenerator.binding.BitField) {
            com.wintec.jmapiCodeGenerator.binding.BitField field = (com.wintec.jmapiCodeGenerator.binding.BitField)object;
            com.wintec.jmapiCodeGenerator.binding.BitField newField = new com.wintec.jmapiCodeGenerator.binding.BitField();
            newField.setName(declaredField.getName());
            if (declaredField.getInterpretation()!=null) {
                newField.setInterpretation(declaredField.getInterpretation());
            } else {
                newField.setInterpretation(field.getInterpretation());
            }
            newField.setOptional(declaredField.isOptional());
            newField.setFieldTypeUnsigned(field.getFieldTypeUnsigned());
            newField.getSubField().addAll(field.getSubField());
            newObject = newField;
        } else if (object instanceof com.wintec.jmapiCodeGenerator.binding.FixedField) {
            com.wintec.jmapiCodeGenerator.binding.FixedField field = (com.wintec.jmapiCodeGenerator.binding.FixedField)object;
            com.wintec.jmapiCodeGenerator.binding.FixedField newField = new com.wintec.jmapiCodeGenerator.binding.FixedField();
            newField.setName(declaredField.getName());
            if (declaredField.getInterpretation()!=null) {
                newField.setInterpretation(declaredField.getInterpretation());
            } else {
                newField.setInterpretation(field.getInterpretation());
            }
            newField.setOptional(declaredField.isOptional());
            newField.setFieldType(field.getFieldType());
            newField.setFieldUnits(field.getFieldUnits());
            newField.setScaleRange(field.getScaleRange());
            newField.setValueSet(field.getValueSet());
            newObject = newField;
        } else if (object instanceof com.wintec.jmapiCodeGenerator.binding.FixedLengthString) {
            com.wintec.jmapiCodeGenerator.binding.FixedLengthString field = (com.wintec.jmapiCodeGenerator.binding.FixedLengthString)object;
            com.wintec.jmapiCodeGenerator.binding.FixedLengthString newField = new com.wintec.jmapiCodeGenerator.binding.FixedLengthString();
            newField.setName(declaredField.getName());
            if (declaredField.getInterpretation()!=null) {
                newField.setInterpretation(declaredField.getInterpretation());
            } else {
                newField.setInterpretation(field.getInterpretation());
            }
            newField.setOptional(declaredField.isOptional());
            newField.setStringLength(field.getStringLength());
            newObject = newField;
        } else if (object instanceof com.wintec.jmapiCodeGenerator.binding.VariableFormatField) {
            com.wintec.jmapiCodeGenerator.binding.VariableFormatField field = (com.wintec.jmapiCodeGenerator.binding.VariableFormatField)object;
            com.wintec.jmapiCodeGenerator.binding.VariableFormatField newField = new com.wintec.jmapiCodeGenerator.binding.VariableFormatField();
            newField.setName(declaredField.getName());
            if (declaredField.getInterpretation()!=null) {
                newField.setInterpretation(declaredField.getInterpretation());
            } else {
                newField.setInterpretation(field.getInterpretation());
            }
            newField.setOptional(declaredField.isOptional());
            newField.setCountField(field.getCountField());
            newField.setFormatField(field.getFormatField());
            newObject = newField;
        } else if (object instanceof com.wintec.jmapiCodeGenerator.binding.VariableLengthField) {
            com.wintec.jmapiCodeGenerator.binding.VariableLengthField field = (com.wintec.jmapiCodeGenerator.binding.VariableLengthField)object;
            com.wintec.jmapiCodeGenerator.binding.VariableLengthField newField = new com.wintec.jmapiCodeGenerator.binding.VariableLengthField();
            newField.setName(declaredField.getName());
            if (declaredField.getInterpretation()!=null) {
                newField.setInterpretation(declaredField.getInterpretation());
            } else {
                newField.setInterpretation(field.getInterpretation());
            }
            newField.setOptional(declaredField.isOptional());
            newField.setCountField(field.getCountField());
            newField.setFieldFormat(field.getFieldFormat());
            newObject = newField;
        } else if (object instanceof com.wintec.jmapiCodeGenerator.binding.VariableLengthString) {
            com.wintec.jmapiCodeGenerator.binding.VariableLengthString field = (com.wintec.jmapiCodeGenerator.binding.VariableLengthString)object;
            com.wintec.jmapiCodeGenerator.binding.VariableLengthString newField = new com.wintec.jmapiCodeGenerator.binding.VariableLengthString();
            newField.setName(declaredField.getName());
            if (declaredField.getInterpretation()!=null) {
                newField.setInterpretation(declaredField.getInterpretation());
            } else {
                newField.setInterpretation(field.getInterpretation());
            }
            newField.setOptional(declaredField.isOptional());
            newField.setCountField(field.getCountField());
            newObject = newField;
        } else if (object instanceof com.wintec.jmapiCodeGenerator.binding.VariableField) {
            com.wintec.jmapiCodeGenerator.binding.VariableField field = (com.wintec.jmapiCodeGenerator.binding.VariableField)object;
            com.wintec.jmapiCodeGenerator.binding.VariableField newField = new com.wintec.jmapiCodeGenerator.binding.VariableField();
            newField.setName(declaredField.getName());
            if (declaredField.getInterpretation()!=null) {
                newField.setInterpretation(declaredField.getInterpretation());
            } else {
                newField.setInterpretation(field.getInterpretation());
            }
            newField.setOptional(declaredField.isOptional());
            newField.setTypeAndUnitsField(field.getTypeAndUnitsField());
            newObject = newField;
        } else if (object instanceof com.wintec.jmapiCodeGenerator.binding.Array) {
            com.wintec.jmapiCodeGenerator.binding.Array field = (com.wintec.jmapiCodeGenerator.binding.Array)object;
            com.wintec.jmapiCodeGenerator.binding.Array newField = new com.wintec.jmapiCodeGenerator.binding.Array();
            newField.setName(declaredField.getName());
            if (declaredField.getInterpretation()!=null) {
                newField.setInterpretation(declaredField.getInterpretation());
            } else {
                newField.setInterpretation(field.getInterpretation());
            }
            newField.setOptional(declaredField.isOptional());
            newField.setBitField(field.getBitField());
            newField.setFixedField(field.getFixedField());
            newField.setDeclaredField(field.getDeclaredField());
            newField.setFixedLengthString(field.getFixedLengthString());
            newField.setVariableField(field.getVariableField());
            newField.setVariableFormatField(field.getVariableFormatField());
            newField.setVariableLengthField(field.getVariableLengthField());
            newField.setVariableLengthString(field.getVariableLengthString());
            newObject = newField;
        } else {
            throw new UnknownDeclaredTypeSetException("Unknown declared field object");
        }
        return newObject;
    }

    private int resolveDeclaredTypes(String defaultDeclaredTypeSetIdVersion, com.wintec.jmapiCodeGenerator.binding.Record b_Record) {
        int numOfChanges = 0;
        if (b_Record != null) {
            java.util.List<Object> fieldList = b_Record.getArrayOrFixedFieldOrVariableField();
            if (fieldList != null) {
                for (int i = 0; i < fieldList.size(); i++) {
                    Object obj = fieldList.get(i);
                    if (obj instanceof com.wintec.jmapiCodeGenerator.binding.DeclaredField) {
                        com.wintec.jmapiCodeGenerator.binding.DeclaredField declaredField = (com.wintec.jmapiCodeGenerator.binding.DeclaredField) obj;
                        Object replacementField = null;
                        if (declaredField.getDeclaredTypeSetRefName() == null) {
                            java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(defaultDeclaredTypeSetIdVersion);
                            if (declaredTypeSet != null) {
                                replacementField = getCopy(declaredTypeSet.get(declaredField.getDeclaredTypeName()), declaredField);
                            }
                        } else {
                            String declaredTypeSetIdVersion = declaredTypeSetRefTable.get(defaultDeclaredTypeSetIdVersion + "|" + declaredField.getDeclaredTypeSetRefName());
                            if (declaredTypeSetIdVersion != null) {
                                java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(declaredTypeSetIdVersion);
                                if (declaredTypeSet != null) {
                                    replacementField = getCopy(declaredTypeSet.get(declaredField.getDeclaredTypeName()), declaredField);
                                }
                            }
                        }
                        if (replacementField != null) {
                            fieldList.remove(i);
                            fieldList.add(i, replacementField);
                            numOfChanges++;
                        } else {
                            throw new UnknownDeclaredTypeSetException("declared_type_set_ref_name = " + declaredField.getDeclaredTypeSetRefName()
                                + "declared_type_name = " + declaredField.getDeclaredTypeName());
                        }
                    }
                }
            }
        }
        return numOfChanges;
    }

    private int resolveDeclaredTypes(String defaultDeclaredTypeSetIdVersion, com.wintec.jmapiCodeGenerator.binding.Array b_Array) {
        int numOfChanges = 0;
        if (b_Array != null && b_Array.getDeclaredField() != null) {
            com.wintec.jmapiCodeGenerator.binding.DeclaredField declaredField = b_Array.getDeclaredField();
            Object replacementField = null;
            if (declaredField.getDeclaredTypeSetRefName() == null) {
                java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(defaultDeclaredTypeSetIdVersion);
                if (declaredTypeSet != null) {
                    replacementField = getCopy(declaredTypeSet.get(declaredField.getDeclaredTypeName()), declaredField);
                }
            } else {
                String declaredTypeSetIdVersion = declaredTypeSetRefTable.get(defaultDeclaredTypeSetIdVersion + "|" + declaredField.getDeclaredTypeSetRefName());
                if (declaredTypeSetIdVersion != null) {
                    java.util.Hashtable<String, Object> declaredTypeSet = declaredTypeSetTable.get(declaredTypeSetIdVersion);
                    if (declaredTypeSet != null) {
                        replacementField = getCopy(declaredTypeSet.get(declaredField.getDeclaredTypeName()), declaredField);
                    }
                }
            }
            if (replacementField != null) {
                b_Array.setDeclaredField(null);
                if (replacementField instanceof com.wintec.jmapiCodeGenerator.binding.BitField) {
                    b_Array.setBitField((com.wintec.jmapiCodeGenerator.binding.BitField) replacementField);
                } else if (replacementField instanceof com.wintec.jmapiCodeGenerator.binding.FixedField) {
                    b_Array.setFixedField((com.wintec.jmapiCodeGenerator.binding.FixedField) replacementField);
                } else if (replacementField instanceof com.wintec.jmapiCodeGenerator.binding.FixedLengthString) {
                    b_Array.setFixedLengthString((com.wintec.jmapiCodeGenerator.binding.FixedLengthString) replacementField);
                } else if (replacementField instanceof com.wintec.jmapiCodeGenerator.binding.VariableFormatField) {
                    b_Array.setVariableFormatField((com.wintec.jmapiCodeGenerator.binding.VariableFormatField) replacementField);
                } else if (replacementField instanceof com.wintec.jmapiCodeGenerator.binding.VariableLengthField) {
                    b_Array.setVariableLengthField((com.wintec.jmapiCodeGenerator.binding.VariableLengthField) replacementField);
                } else if (replacementField instanceof com.wintec.jmapiCodeGenerator.binding.VariableLengthString) {
                    b_Array.setVariableLengthString((com.wintec.jmapiCodeGenerator.binding.VariableLengthString) replacementField);
                } else if (replacementField instanceof com.wintec.jmapiCodeGenerator.binding.VariableField) {
                    b_Array.setVariableField((com.wintec.jmapiCodeGenerator.binding.VariableField) replacementField);
                } else {
                    throw new MessageConstructionException("Invalid field specification of array: " + replacementField.getClass().getName());
                }
                numOfChanges++;
            } else {
                throw new UnknownDeclaredTypeSetException("declared_type_set_ref_name = " + declaredField.getDeclaredTypeSetRefName()
                    + "declared_type_name = " + declaredField.getDeclaredTypeName());
            }
        }
        return numOfChanges;
    }

    private ServiceDef getServiceDef(File file) throws Exception {
        if (file.exists()) {
            InputStream inputStream = new FileInputStream(file);
            ServiceDef b_ServiceDef = (ServiceDef) unmarshaller.unmarshal(inputStream);
            inputStream.close();
            if (b_ServiceDef != null) {
                if (b_ServiceDef.getDeclaredTypeSet() != null) {
                    if (b_ServiceDef.getDeclaredTypeSet().getId() == null) {
                        b_ServiceDef.getDeclaredTypeSet().setId(b_ServiceDef.getId());
                        b_ServiceDef.getDeclaredTypeSet().setVersion(b_ServiceDef.getVersion());
                    }
                    processDeclaredTypeSet(b_ServiceDef.getDeclaredTypeSet());
                    resolveDeclaredTypesInDeclaredTypeSet();
                }
                for (com.wintec.jmapiCodeGenerator.binding.MessageDef messageDef : b_ServiceDef.getMessageSet().getMessageDef()) {
                    resolveDeclaredTypes(b_ServiceDef.getId() + "|" + b_ServiceDef.getVersion(), messageDef);
                }
                return b_ServiceDef;
            }
        }
        gui.getProgressBox().append("File not found: "+ file.getPath()+"\n");
        gui.getProgressBoxVerticalScrollBar().setValue(gui.getProgressBoxVerticalScrollBar().getMaximum());
        return null;
    }

    public void setCancel() {
        cancelFlag = true;
    }

    public void run() {
        cancelFlag = false;
        gui.getProgressBox().append("Code generation started...\n");
        gui.getProgressBar().setIndeterminate(true);
        gui.getGenButton().setText("Cancel");
        boolean complete = false;
        try {
            File targetDir = new File(gui.getTargetDirectory());
            if (!targetDir.exists()) {
                int answer = JOptionPane.showConfirmDialog(gui, "Do you want to create a directory " + gui.getTargetDirectory() + " ?",
                                "Create Directory", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (answer==JOptionPane.YES_OPTION) {
                    targetDir.mkdir();
                } else {
                    return;
                }
            }

            new File(gui.getTargetDirectory()+"/include").mkdir();
            new File(gui.getTargetDirectory()+"/src").mkdir();

            Calendar cal = Calendar.getInstance();
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMMMM yyyy, hh:mm:ss z");

            // load templates for base classes
            String statemap_h = CodeGen.getTemplate("statemap.h.tpl");
            TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/include/statemap.h"), statemap_h);
            
	        String service_h = CodeGen.getTemplate("service.h.tpl").replace("%time_stamp%", sdf.format(cal.getTime())).replace("%root_namespace%", ROOT_NAMESPACE);
	        TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/include/Service.h"), service_h);

	        String service_cpp = CodeGen.getTemplate("service.cpp.tpl").replace("%time_stamp%", sdf.format(cal.getTime())).replace("%root_namespace%", ROOT_NAMESPACE);
	        TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/src/Service.cpp"), service_cpp);

            String message_h = CodeGen.getTemplate("message.h.tpl").replace("%time_stamp%", sdf.format(cal.getTime())).replace("%root_namespace%", ROOT_NAMESPACE);
        	TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/include/Message.h"), message_h);

            String message_cpp = CodeGen.getTemplate("message.cpp.tpl").replace("%time_stamp%", sdf.format(cal.getTime())).replace("%root_namespace%", ROOT_NAMESPACE);
            TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/src/Message.cpp"), message_cpp);

            String header_h = CodeGen.getTemplate("header.h.tpl").replace("%time_stamp%", sdf.format(cal.getTime())).replace("%root_namespace%", ROOT_NAMESPACE);
            TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/include/Header.h"), header_h);

            String jausutils_h = CodeGen.getTemplate("jausutils.h.tpl").replace("%time_stamp%", sdf.format(cal.getTime())).replace("%root_namespace%", ROOT_NAMESPACE);
            TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/include/JausUtils.h"), jausutils_h);

            String jauscomponent_h = CodeGen.getTemplate("jauscomponent.h.tpl").replace("%time_stamp%", sdf.format(cal.getTime())).replace("%root_namespace%", ROOT_NAMESPACE);
            TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/include/JausComponent.h"), jauscomponent_h);

            String jauscomponent_cpp = CodeGen.getTemplate("jauscomponent.cpp.tpl").replace("%time_stamp%", sdf.format(cal.getTime())).replace("%root_namespace%", ROOT_NAMESPACE);
            TextFileHandler.setContentsAndWrite(new File(gui.getTargetDirectory()+"/src/JausComponent.cpp"), jauscomponent_cpp);


            for(int i=0; i<gui.getServiceDefListModel().getSize(); i++) {
                if (cancelFlag) break;
                ServiceDef serviceDef = getServiceDef((File)gui.getServiceDefListModel().getElementAt(i));
                gui.getProgressBox().append("Processing: " + serviceDef.getName()+"\n");
                gui.getProgressBoxVerticalScrollBar().setValue(gui.getProgressBoxVerticalScrollBar().getMaximum());
                ServiceClass serviceClass = new ServiceClass(serviceDef);
                serviceClass.startProcess();
                String dirname = serviceClass.getDirName();
                Enumeration<String> filenames = serviceClass.getSourceCodeSet().keys();
                new File(gui.getTargetDirectory()+"/include/"+dirname).mkdir();
                new File(gui.getTargetDirectory()+"/src/"+dirname).mkdir();
                while(filenames.hasMoreElements()) {
                    String filename = filenames.nextElement();
                    File file;
                    if (filename.endsWith(".h")) {
                        file = new File(gui.getTargetDirectory()+"/include/"+dirname+"/"+filename);
                    } else {
                        file = new File(gui.getTargetDirectory()+"/src/"+dirname+"/"+filename);
                    }
                    TextFileHandler.setContentsAndWrite(file, serviceClass.getSourceCodeSet().get(filename));
                }
                ProtocolBehaviorClass pbc = new ProtocolBehaviorClass(gui.getTargetDirectory(), dirname, ProtocolBehaviorClass.C_PLUS_PLUS, serviceDef);
                pbc.startProcess();
            }
            complete = true;
        } catch (Exception e) {
            e.printStackTrace();
            gui.getProgressBox().append(e.toString()+"\n");
            gui.getProgressBoxVerticalScrollBar().setValue(gui.getProgressBoxVerticalScrollBar().getMaximum());
        }
        gui.getProgressBar().setIndeterminate(false);
        gui.getGenButton().setText("Generate");
        if (cancelFlag || !complete) {
            gui.getProgressBox().append("Code generation cancelled...\n");
            gui.getProgressBoxVerticalScrollBar().setValue(gui.getProgressBoxVerticalScrollBar().getMaximum());
        } else {
            gui.getProgressBox().append("Code generation completed...\n");
            gui.getProgressBoxVerticalScrollBar().setValue(gui.getProgressBoxVerticalScrollBar().getMaximum());
            JOptionPane.showMessageDialog(gui, "The code generation completed.");
        }
    }
}