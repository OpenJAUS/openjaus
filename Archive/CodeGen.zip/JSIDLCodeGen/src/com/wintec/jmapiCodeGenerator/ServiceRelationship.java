/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

public class ServiceRelationship {
	private String namespace;
	private String serviceName;
	private String includeStatement;
	
	public ServiceRelationship(String id, String name, String version) {
		namespace = ServiceClass.makeNamespace(id,version);
		serviceName = name;
		includeStatement = "#include <"+namespace+"/"+name+"Client.h>"+CodeGen.LINE_END;
	}
	
	public String getNamespace() {
		return namespace;
	}

	public String getServiceName() {
		return serviceName;
	}

	public String getIncludeStatement() {
		return includeStatement;
	}
}

