/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.List;
import com.wintec.jmapiCodeGenerator.binding.ListCount;
import com.wintec.jmapiCodeGenerator.binding.Record;
import com.wintec.jmapiCodeGenerator.binding.RecordCount;

import java.util.HashSet;
import java.util.Vector;

public class ListClass {

    private List list;

    private String enclosingClassName;
    private int level;
    private CodeLines codeLines;
    private HashSet<String> definedClassList;

    public ListClass(List list, String enclosingClassName, int level) throws RuntimeException {
        this.list = list;
        this.level = level + 1;
        String enclosingShortClassName = enclosingClassName.substring(enclosingClassName.lastIndexOf("::")+2);
        if (enclosingShortClassName.equalsIgnoreCase(getShortClassName())) {
            throw new RuntimeException(getShortClassName()+ " : a nested element cannot have the same name as the immediately enclosing element.");
        }
        this.enclosingClassName = enclosingClassName;
        codeLines = new CodeLines();
        definedClassList = new HashSet<String>();
    }

    public void startProcess() throws RuntimeException {
        CodeLines codes = new CodeLines();
        RecordCount recordCount = list.getRecordCount();
        if(recordCount!=null) {
            /// record_count
            String recordCountType = CodeGen.getVariableType(recordCount.getCountField().getFieldTypeUnsigned());
            String recordCountName = CodeGen.upperCaseFirstLetter(recordCount.getName());
            codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(recordCountType, recordCountName, false));
            codes.constructorLines.add(CodeGen.getVariableName(recordCountName)+" = 0;");

            codes.encoderLines.add("memcpy(bytes+pos, &"+CodeGen.getVariableName(recordCountName)+", sizeof("+CodeGen.getVariableName(recordCountName)+"));");
            codes.encoderLines.add("pos += sizeof("+CodeGen.getVariableName(recordCountName)+");");

            codes.decoderLines.add("memcpy(&"+CodeGen.getVariableName(recordCountName)+", bytes+pos, sizeof("+CodeGen.getVariableName(recordCountName)+"));");
            codes.decoderLines.add("pos += sizeof("+CodeGen.getVariableName(recordCountName)+");");

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(recordCountType, "get", recordCountName, null));
            Vector<String> rcGetMethod = new Vector<String>();
            rcGetMethod.add("return "+ CodeGen.getVariableName(recordCountName) + ";");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(recordCountType, getLongClassName() +"::get", recordCountName, null,rcGetMethod));

            /// list of records
            Record record = list.getRecord();
            /// creating record wrapper class
            RecordClass recordClass = new RecordClass(record, getLongClassName(), level, definedClassList);
            if (!definedClassList.contains(recordClass.getLongClassName())) {
                codes.add(recordClass.getCodeLines(CodeGen.WITH_WRAPPER_CLASS));
                definedClassList.add(recordClass.getLongClassName());
            } else {
                throw new RuntimeException("Duplicated element names: "+ recordClass.getLongClassName());
            }
            codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("vector<"+recordClass.getLongClassName()+"*>", recordClass.getShortClassName(), false));

            codes.destructorLines.add("for("+recordCountType+" i=0; i<"+CodeGen.getVariableName(recordCountName)+"; i++) {");
            codes.destructorLines.add("    delete "+ CodeGen.getVariableName(recordClass.getShortClassName())+".at(i);");
            codes.destructorLines.add("}");

            codes.encoderLines.add("for("+recordCountType+" i=0; i<"+CodeGen.getVariableName(recordCountName)+"; i++) {");
            codes.encoderLines.add("    "+ CodeGen.getVariableName(recordClass.getShortClassName())+".at(i)->encode(bytes, pos);");
            codes.encoderLines.add("}");

            codes.decoderLines.add("for("+recordCountType+" i=0; i<"+CodeGen.getVariableName(recordCountName)+"; i++) {");
            codes.decoderLines.add("    "+CodeGen.getVariableName(recordClass.getShortClassName())+".push_back(new "+recordClass.getShortClassName()+"());");
            codes.decoderLines.add("    "+CodeGen.getVariableName(recordClass.getShortClassName())+".back()->decode(bytes, pos);");
            codes.decoderLines.add("}");

            Vector<String> rGetMethodParam = new Vector<String>();
            rGetMethodParam.add(recordCountType+" index");

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(recordClass.getLongClassName(), "*get", recordClass.getShortClassName(), rGetMethodParam));
            Vector<String> rGetMethodCode = new Vector<String>();
            rGetMethodCode.add("return "+ CodeGen.getVariableName(recordClass.getShortClassName()) + ".at(index);");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(recordClass.getLongClassName(), "*"+ getLongClassName() +"::"+"get", recordClass.getShortClassName(), rGetMethodParam,rGetMethodCode));

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(recordClass.getLongClassName(), "*append", recordClass.getShortClassName(), null));
            Vector<String> rAppendMethodCode = new Vector<String>();
            rAppendMethodCode.add(CodeGen.getVariableName(recordClass.getShortClassName()) + ".push_back(new "+recordClass.getLongClassName()+"());");
            rAppendMethodCode.add(CodeGen.getVariableName(recordCountName) + "++;");
            rAppendMethodCode.add("return "+CodeGen.getVariableName(recordClass.getShortClassName())+".back();");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(recordClass.getLongClassName(), "*"+ getLongClassName() +"::"+"append", recordClass.getShortClassName(), null,rAppendMethodCode));

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(recordClass.getLongClassName(), "*insert", recordClass.getShortClassName(), rGetMethodParam));
            Vector<String> rInsertMethodCode = new Vector<String>();
            //rInsertMethodCode.add("vector<"+recordClass.getLongClassName()+"*>::iterator itr = "+CodeGen.getVariableName(recordClass.getShortClassName())+".insert("
            //    +CodeGen.getVariableName(recordClass.getShortClassName())+".begin()+index, new "+recordClass.getLongClassName()+"());");
            rInsertMethodCode.add(CodeGen.getVariableName(recordCountName) + "++;");
            rInsertMethodCode.add("return "+ CodeGen.getVariableName(recordClass.getShortClassName()) + ".at(index);");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(recordClass.getLongClassName(), "*"+ getLongClassName() +"::"+"insert", recordClass.getShortClassName(), rGetMethodParam,rInsertMethodCode));

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "remove", recordClass.getShortClassName(), rGetMethodParam));
            Vector<String> rRemoveMethodCode = new Vector<String>();
            rRemoveMethodCode.add("delete "+CodeGen.getVariableName(recordClass.getShortClassName())+".at(index);");
            rRemoveMethodCode.add(CodeGen.getVariableName(recordClass.getShortClassName()) + ".erase("+CodeGen.getVariableName(recordClass.getShortClassName())+".begin()+index);");
            rRemoveMethodCode.add(CodeGen.getVariableName(recordCountName) + "--;");
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName() +"::"+"remove", recordClass.getShortClassName(), rGetMethodParam,rRemoveMethodCode));
        } else {
            /// a record
            Record record = list.getRecord();
            if (record!=null) {
                RecordClass recordClass = new RecordClass(record, getLongClassName(), level, definedClassList);
                codes.add(recordClass.getCodeLines(CodeGen.WITHOUT_WRAPPER_CLASS));
            }
        }
        java.util.List<Object> listList = list.getListCountAndListOrDeclaredList();
        for(int i=0; i<listList.size();i++) {
            if (listList.get(i) instanceof ListCount) {
                /// get list_count
                ListCount listCount = (ListCount)listList.get(i);
                String listCountType = CodeGen.getVariableType(listCount.getCountField().getFieldTypeUnsigned());
                String listCountName = CodeGen.upperCaseFirstLetter(listCount.getName());
                codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(listCountType, listCountName, false));
                codes.constructorLines.add(CodeGen.getVariableName(listCountName)+" = 0;");

                codes.encoderLines.add("memcpy(bytes+pos, &"+CodeGen.getVariableName(listCountName)+", sizeof("+CodeGen.getVariableName(listCountName)+"));");
                codes.encoderLines.add("pos += sizeof("+CodeGen.getVariableName(listCountName)+");");

                codes.decoderLines.add("memcpy(&"+CodeGen.getVariableName(listCountName)+", bytes+pos, sizeof("+CodeGen.getVariableName(listCountName)+"));");
                codes.decoderLines.add("pos += sizeof("+CodeGen.getVariableName(listCountName)+");");

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listCountType, "get", listCountName, null));
                Vector<String> lcGetMethodCode = new Vector<String>();
                lcGetMethodCode.add("return "+ CodeGen.getVariableName(listCountName) + ";");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listCountType, getLongClassName() +"::"+"get", listCountName, null,lcGetMethodCode));

                /// get list
                List subList = (List)listList.get(++i);
                /// list class
                ListClass listClass = new ListClass(subList, getLongClassName(), level);
                if (!definedClassList.contains(listClass.getLongClassName())) {
                    codes.add(listClass.getCodeLines());
                    definedClassList.add(listClass.getLongClassName());
                } else {
                    throw new RuntimeException("Duplicated element names: "+listClass.getLongClassName());
                }
                codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration("vector<"+listClass.getLongClassName()+"*>", listClass.getShortClassName(), false));

                codes.destructorLines.add("for("+listCountType+" i=0; i<"+CodeGen.getVariableName(listCountName)+"; i++) {");
                codes.destructorLines.add("    delete "+ CodeGen.getVariableName(listClass.getShortClassName())+".at(i);");
                codes.destructorLines.add("}");

                codes.encoderLines.add("for("+listCountType+" i=0; i<"+CodeGen.getVariableName(listCountName)+"; i++) {");
                codes.encoderLines.add("    "+ CodeGen.getVariableName(listClass.getShortClassName())+".at(i)->encode(bytes, pos);");
                codes.encoderLines.add("}");

                codes.decoderLines.add("for("+listCountType+" i=0; i<"+CodeGen.getVariableName(listCountName)+"; i++) {");
                codes.decoderLines.add("    "+CodeGen.getVariableName(listClass.getShortClassName())+".push_back(new "+listClass.getShortClassName()+"());");
                codes.decoderLines.add("    "+CodeGen.getVariableName(listClass.getShortClassName())+".back()->decode(bytes, pos);");
                codes.decoderLines.add("}");

                Vector<String> lGetMethodParam = new Vector<String>();
                lGetMethodParam.add(listCountType+" index");

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listClass.getLongClassName(), "*get", listClass.getShortClassName(), lGetMethodParam));
                Vector<String> lGetMethodCode = new Vector<String>();
                lGetMethodCode.add("return "+ CodeGen.getVariableName(listClass.getShortClassName()) + ".at(index);");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listClass.getLongClassName(), "*"+ getLongClassName() +"::"+"get", listClass.getShortClassName(), lGetMethodParam,lGetMethodCode));

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listClass.getLongClassName(), "*append", listClass.getShortClassName(), null));
                Vector<String> lAppendMethodCode = new Vector<String>();
                lAppendMethodCode.add(CodeGen.getVariableName(listClass.getShortClassName()) + ".push_back(new "+listClass.getLongClassName()+"());");
                lAppendMethodCode.add(CodeGen.getVariableName(listCountName) + "++;");
                lAppendMethodCode.add("return "+CodeGen.getVariableName(listClass.getShortClassName())+".back();");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listClass.getLongClassName(), "*"+ getLongClassName() +"::"+"append", listClass.getShortClassName(), null,lAppendMethodCode));

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listClass.getLongClassName(), "*insert", listClass.getShortClassName(), lGetMethodParam));
                Vector<String> lInsertMethodCode = new Vector<String>();
                //lInsertMethodCode.add("vector<"+listClass.getLongClassName()+"*>::iterator itr = "+CodeGen.getVariableName(listClass.getShortClassName())+".insert("
                //    +CodeGen.getVariableName(listClass.getShortClassName())+".begin()+index, new "+listClass.getLongClassName()+"());");
                lInsertMethodCode.add(CodeGen.getVariableName(listCountName) + "++;");
                lInsertMethodCode.add("return "+ CodeGen.getVariableName(listClass.getShortClassName()) + ".at(index);");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listClass.getLongClassName(), "*"+ getLongClassName() +"::"+"insert", listClass.getShortClassName(), lGetMethodParam,lInsertMethodCode));

                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "remove", listClass.getShortClassName(), lGetMethodParam));
                Vector<String> lRemoveMethodCode = new Vector<String>();
                lRemoveMethodCode.add("delete "+CodeGen.getVariableName(listClass.getShortClassName())+".at(index);");
                lRemoveMethodCode.add(CodeGen.getVariableName(listClass.getShortClassName()) + ".erase("+CodeGen.getVariableName(listClass.getShortClassName())+".begin()+index);");
                lRemoveMethodCode.add(CodeGen.getVariableName(listCountName) + "--;");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName() +"::"+"remove", listClass.getShortClassName(), lGetMethodParam,lRemoveMethodCode));


            } else if (listList.get(i) instanceof List) {
                /// get list
                List list = (List)listList.get(i);
                /// list class
                ListClass listClass = new ListClass(list, getLongClassName(), level);
                if (!definedClassList.contains(listClass.getLongClassName())) {
                    codes.add(listClass.getCodeLines());
                    definedClassList.add(listClass.getLongClassName());
                } else {
                    throw new RuntimeException("Duplicated element names: "+ listClass.getLongClassName());
                }
                /// list member variable
                codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(listClass.getLongClassName(), listClass.getShortClassName(), false));
                codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(listClass.getLongClassName(), "*get", listClass.getShortClassName(), null));
                Vector<String> lGetMethodCode = new Vector<String>();
                lGetMethodCode.add("return &"+ CodeGen.getVariableName(listClass.getShortClassName()) + ";");
                codes.methodCodes.addAll(CodeGen.createMethodDefinition(listClass.getLongClassName(), "*"+ getLongClassName() +"::"+"get", listClass.getShortClassName(), null,lGetMethodCode));
                codes.encoderLines.add(CodeGen.getVariableName(listClass.getShortClassName())+".encode(bytes, pos);");
                codes.decoderLines.add(CodeGen.getVariableName(listClass.getShortClassName())+".decode(bytes, pos);");
            }
        }

        Vector<String> param = new Vector<String>();
        param.add("unsigned char *bytes");
        param.add("int &pos");

        Vector<String> param2 = new Vector<String>();
        param2.add("unsigned char *bytes");
        param2.add("int &pos");

        /// class encoder
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "encode", null, param));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::encode", null, param, codes.encoderLines));

        /// class decoder
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "decode", null, param2));
        codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::decode", null, param2, codes.decoderLines));

        codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"class "+getShortClassName()+" {");
        if (codes.classDefinitions.size()>0) {
            codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  public:");
            codeLines.classDefinitions.addAll(codes.classDefinitions);
        }
        if (codes.protectedAttributes.size()>0 || codes.protectedMethods.size()>0) {
            codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  private:");
            codeLines.classDefinitions.addAll(codes.protectedAttributes);
            codeLines.classDefinitions.addAll(codes.protectedMethods);
        }
        codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  public:");
        codeLines.classDefinitions.addAll(codes.publicAttributes);
        if (!codes.constructorLines.isEmpty()) {
            codeLines.classDefinitions.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, null, getShortClassName(), null));
            codeLines.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName()+"::", getShortClassName(), null, codes.constructorLines));
        }
        if (!codes.destructorLines.isEmpty()) {
            codeLines.classDefinitions.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, "~", getShortClassName(), null));
            codeLines.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName()+"::~", getShortClassName(), null, codes.destructorLines));
        }
        codeLines.classDefinitions.addAll(codes.publicMethods);
        codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"};");
        codeLines.methodCodes.addAll(codes.methodCodes);

    }

    public CodeLines getCodeLines() {
        startProcess();
        return codeLines;
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(list.getName());
    }

    public String getLongClassName() {
        return enclosingClassName+"::"+getShortClassName();
    }
}
