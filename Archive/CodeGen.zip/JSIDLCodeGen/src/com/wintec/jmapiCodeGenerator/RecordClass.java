/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
*********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import com.wintec.jmapiCodeGenerator.binding.*;

import java.util.HashSet;
import java.util.Vector;

public class RecordClass {

    private Record record;
    private String enclosingClassName;
    private int level;
    private CodeLines codeLines;
    private boolean useWrapperClass;
    private HashSet<String> definedClassList;
    private int presenceVectorIndex;

    public RecordClass(Record record, String enclosingClassName, int level, HashSet<String> definedClassList) {
        this.record = record;
        this.enclosingClassName = enclosingClassName;
        this.level = level;
        this.definedClassList = definedClassList;
        presenceVectorIndex = -1;
    }

    public void startProcess() throws RuntimeException {
        CodeLines codes = new CodeLines();
        if (hasPresenceVector()) {

            String pvType = CodeGen.getVariableType(record.getPresenceVector().getFieldTypeUnsigned());

            codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(pvType, "PresenceVector", false));
            codes.constructorLines.add(CodeGen.getVariableName("PresenceVector")+" = 0;");

            codes.encoderLines.add(pvType+" pvTemp_;");
            codes.encoderLines.add("pvTemp_ = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness("+CodeGen.getVariableName("PresenceVector")+");");
            codes.encoderLines.add("memcpy(bytes+pos, &pvTemp_, sizeof("+pvType+"));");
            codes.encoderLines.add("pos += sizeof("+pvType+");");

            codes.decoderLines.add(pvType+" pvTemp_;");
            codes.decoderLines.add("memcpy(&pvTemp_, bytes+pos, sizeof("+pvType+"));");
            codes.decoderLines.add(CodeGen.getVariableName("PresenceVector")+" = "+CodeGen.ROOT_NAMESPACE+"::correctEndianness(pvTemp_);");
            codes.decoderLines.add("pos += sizeof("+pvType+");");

            Vector<String> pvGetMethodCode = new Vector<String>();
            pvGetMethodCode.add("return "+ CodeGen.getVariableName("PresenceVector") + ";");
            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(pvType, "get", "PresenceVector", null));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition(pvType, getLongClassName() +"::get", "PresenceVector", null,pvGetMethodCode));

            Vector<String> pvSetMethodParam = new Vector<String>();
            pvSetMethodParam.add("int index");
            Vector<String> pvSetMethodCode = new Vector<String>();
            pvSetMethodCode.add("bitset<"+(CodeGen.getVariableSize(record.getPresenceVector().getFieldTypeUnsigned())*8)+"> pvBitSet("+CodeGen.getVariableName("PresenceVector")+");");
            pvSetMethodCode.add("pvBitSet[index] = 1;");
            pvSetMethodCode.add(CodeGen.getVariableName("PresenceVector")+" = ("+pvType+")pvBitSet.to_ulong();");
            codes.protectedMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "set", "PresenceVector", pvSetMethodParam));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName() +"::set", "PresenceVector", pvSetMethodParam,pvSetMethodCode));

            Vector<String> pvCheckMethodParam = new Vector<String>();
            pvCheckMethodParam.add("int index");
            Vector<String> pvCheckMethodCode = new Vector<String>();
            pvCheckMethodCode.add("bitset<"+(CodeGen.getVariableSize(record.getPresenceVector().getFieldTypeUnsigned())*8)+"> pvBitSet("+CodeGen.getVariableName("PresenceVector")+");");
            pvCheckMethodCode.add("return (pvBitSet[index] == 1);");
            codes.protectedMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("bool", "check", "PresenceVector", pvCheckMethodParam));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("bool", getLongClassName() +"::check", "PresenceVector", pvCheckMethodParam,pvCheckMethodCode));

        }
        for(Object field:record.getArrayOrFixedFieldOrVariableField()) {
            if (field instanceof Array) {

                Array array = (Array)field;
                if (array.isOptional()) presenceVectorIndex++;
                ArrayClass arrayClass = new ArrayClass(this, array, getLongClassName(), level);
                codes.add(arrayClass.getCodeLines());

            } else if (field instanceof BitField) {

                BitField bitField = (BitField)field;
                if (bitField.isOptional()) presenceVectorIndex++;
                FieldClass fieldClass = new BitFieldClass(this, bitField, getLongClassName(), level);
                wrapWithClass(fieldClass, codes);

            } else if (field instanceof FixedField) {

                FixedField fixedField = (FixedField)field;
                if (fixedField.isOptional()) presenceVectorIndex++;
                FieldClass fieldClass = new FixedFieldClass(this, fixedField, getLongClassName(), level);
                codes.add(fieldClass.getCodeLines(CodeGen.WITHOUT_WRAPPER_CLASS));

            } else if (field instanceof FixedLengthString) {

                FixedLengthString fixedLengthString = (FixedLengthString)field;
                if (fixedLengthString.isOptional()) presenceVectorIndex++;
                FieldClass fieldClass = new FixedLengthStringClass(this, fixedLengthString, getLongClassName(), level);
                codes.add(fieldClass.getCodeLines(CodeGen.WITHOUT_WRAPPER_CLASS));

            } else if (field instanceof VariableField) {

                VariableField variableField = (VariableField)field;
                if (variableField.isOptional()) presenceVectorIndex++;
                FieldClass fieldClass = new VariableFieldClass(this, variableField, getLongClassName(), level);
                wrapWithClass(fieldClass, codes);

            } else if (field instanceof VariableFormatField) {

                VariableFormatField variableFormatField = (VariableFormatField)field;
                if (variableFormatField.isOptional()) presenceVectorIndex++;
                FieldClass fieldClass = new VariableFormatFieldClass(this, variableFormatField, getLongClassName(), level);
                codes.add(fieldClass.getCodeLines(CodeGen.WITHOUT_WRAPPER_CLASS));

            } else if (field instanceof VariableLengthField) {

                VariableLengthField variableLengthField = (VariableLengthField)field;
                if (variableLengthField.isOptional()) presenceVectorIndex++;
                FieldClass fieldClass = new VariableLengthFieldClass(this, variableLengthField, getLongClassName(), level);
                codes.add(fieldClass.getCodeLines(CodeGen.WITHOUT_WRAPPER_CLASS));

            } else if (field instanceof VariableLengthString) {

                VariableLengthString variableLengthString = (VariableLengthString)field;
                if (variableLengthString.isOptional()) presenceVectorIndex++;
                FieldClass fieldClass = new VariableLengthStringClass(this, variableLengthString, getLongClassName(), level);
                codes.add(fieldClass.getCodeLines(CodeGen.WITHOUT_WRAPPER_CLASS));

            } else {

                throw new RuntimeException("Invalid Record Specification: unknown field of "+field.getClass().getName());

            }
        }

        if (useWrapperClass) {

            String enclosingShortClassName = enclosingClassName.substring(enclosingClassName.lastIndexOf("::")+2);
            if (enclosingShortClassName.equalsIgnoreCase(getShortClassName())) {
                throw new RuntimeException(getShortClassName()+ " : a nested element cannot have the same name as the immediately enclosing element.");
            }

            codeLines = new CodeLines();

            Vector<String> param = new Vector<String>();
            param.add("unsigned char *bytes");
            param.add("int &pos");

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "encode", null, param));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::encode", null, param, codes.encoderLines));

            codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration("void", "decode", null, param));
            codes.methodCodes.addAll(CodeGen.createMethodDefinition("void", getLongClassName()+"::decode", null, param, codes.decoderLines));

            codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"class "+getShortClassName()+" {");
            if (codes.classDefinitions.size()>0) {
                codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  public:");
                codeLines.classDefinitions.addAll(codes.classDefinitions);
            }
            if (codes.protectedAttributes.size()>0 || codes.protectedMethods.size()>0) {
                codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  private:");
                codeLines.classDefinitions.addAll(codes.protectedAttributes);
                codeLines.classDefinitions.addAll(codes.protectedMethods);
            }
            codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"  public:");
            codeLines.classDefinitions.addAll(codes.publicAttributes);
            if (!codes.constructorLines.isEmpty()) {
                codeLines.classDefinitions.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, null, getShortClassName(), null));
                codeLines.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName()+"::", getShortClassName(), null,
                    codes.constructorLines));
            }
            if (!codes.destructorLines.isEmpty()) {
                codeLines.classDefinitions.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(null, "~", getShortClassName(), null));
                codeLines.methodCodes.addAll(CodeGen.createMethodDefinition(null, getLongClassName()+"::~", getShortClassName(), null,
                    codes.destructorLines));
            }
            codeLines.classDefinitions.addAll(codes.publicMethods);
            codeLines.classDefinitions.add(CodeGen.tabs(level-1)+"};");
            codeLines.methodCodes.addAll(codes.methodCodes);
        } else {
            codeLines = codes;
        }
    }

    public HashSet<String> getDefinedClassList() {
        return definedClassList;
    }

    public boolean hasPresenceVector() {
        return (record.getPresenceVector()!=null);
    }

    public int getPresenceVectorIndex() {
        return presenceVectorIndex;
    }

    public CodeLines getCodeLines(boolean useWrapperClass) {
        this.useWrapperClass = useWrapperClass;
        if (useWrapperClass) {
            this.level = level + 1;
        }
        startProcess();
        return codeLines;
    }

    public String getShortClassName() {
        return CodeGen.upperCaseFirstLetter(record.getName());
    }

    public String getLongClassName() {
        if (useWrapperClass) {
            return enclosingClassName+"::"+getShortClassName();
        }
		return enclosingClassName;
    }

    private void wrapWithClass(FieldClass fieldClass, CodeLines codes) {
        if (!definedClassList.contains(fieldClass.getLongClassName())) {
            codes.add(fieldClass.getCodeLines(CodeGen.WITH_WRAPPER_CLASS));
            definedClassList.add(fieldClass.getLongClassName());
        }
        codes.protectedAttributes.add(CodeGen.tabs(level)+CodeGen.createVariableDeclaration(fieldClass.getLongClassName(), fieldClass.getShortClassName(), false));

        String tab = "";
        if (hasPresenceVector()) {
            codes.encoderLines.add("if (checkPresenceVector("+ getPresenceVectorIndex() +")) {");
            codes.decoderLines.add("if (checkPresenceVector("+ getPresenceVectorIndex() +")) {");
            tab = "    ";
        }
        codes.encoderLines.add(tab+CodeGen.getVariableName(fieldClass.getShortClassName())+".encode(bytes, pos);");
        codes.decoderLines.add(tab+CodeGen.getVariableName(fieldClass.getShortClassName())+".decode(bytes, pos);");
        if (hasPresenceVector()) {
            codes.encoderLines.add("}");
            codes.decoderLines.add("}");
        }

        codes.constructorLines.add(CodeGen.getVariableName(fieldClass.getShortClassName())+".setParent(this);");
        codes.publicMethods.add(CodeGen.tabs(level)+CodeGen.createMethodDeclaration(fieldClass.getLongClassName(), "*get", fieldClass.getShortClassName(), null));
        Vector<String> fieldGetMethodCode = new Vector<String>();
        fieldGetMethodCode.add("return &"+ CodeGen.getVariableName(fieldClass.getShortClassName()) + ";");
        codes.methodCodes.addAll(CodeGen.createMethodDefinition(fieldClass.getLongClassName(), "*"+ getLongClassName() +"::get", fieldClass.getShortClassName(), null,fieldGetMethodCode));
    }
}
