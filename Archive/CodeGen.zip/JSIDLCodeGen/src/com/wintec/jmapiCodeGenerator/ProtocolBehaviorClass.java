/********************************************************************************
Copyright (C) 2007  WINTEC, Inc.

Sponsored by Air Force Research Laboratory, Tyndall AFB,
The Office of Naval Research, Naval Surface Warfare Center Panama City, and
Technical Support Working Group.

All Rights Reserved.
 *********************************************************************************/
package com.wintec.jmapiCodeGenerator;

import java.io.File;
import java.io.FileWriter;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.io.BufferedReader;
import java.io.FileReader;

import net.sf.smc.Smc;

import com.wintec.jmapiCodeGenerator.binding.Action;
import com.wintec.jmapiCodeGenerator.binding.Argument;
import com.wintec.jmapiCodeGenerator.binding.DefaultState;
import com.wintec.jmapiCodeGenerator.binding.DefaultTransition;
import com.wintec.jmapiCodeGenerator.binding.EndState;
import com.wintec.jmapiCodeGenerator.binding.Entry;
import com.wintec.jmapiCodeGenerator.binding.Exit;
import com.wintec.jmapiCodeGenerator.binding.Guard;
import com.wintec.jmapiCodeGenerator.binding.Map;
import com.wintec.jmapiCodeGenerator.binding.Parameter;
import com.wintec.jmapiCodeGenerator.binding.Pop;
import com.wintec.jmapiCodeGenerator.binding.ProtocolBehavior;
import com.wintec.jmapiCodeGenerator.binding.Push;
import com.wintec.jmapiCodeGenerator.binding.ServiceDef;
import com.wintec.jmapiCodeGenerator.binding.Simple;
import com.wintec.jmapiCodeGenerator.binding.Start;
import com.wintec.jmapiCodeGenerator.binding.State;
import com.wintec.jmapiCodeGenerator.binding.Transition;

public class ProtocolBehaviorClass {

	public static final String C_PLUS_PLUS = new String("C_PLUS_PLUS");
	public static final String JAVA = new String("JAVA");
	private String targetDest = null; // target destination directory
	private String dirname = null;
	private String targetLang = null; // target language
	private String jsidlSrcFileName = null; // jsidl source file name
	private ServiceDef _sd;

	public ProtocolBehaviorClass(String targetDest, String dirname,
			String targetLang, ServiceDef _sd) {
		this._sd = _sd;
		this.targetDest = targetDest;
		this.dirname = dirname;
		this.targetLang = targetLang;
		this.jsidlSrcFileName = _sd.getName();

		if (targetLang == null || !targetLang.equals("C_PLUS_PLUS")
				|| !targetLang.equals("JAVA"))
			this.targetLang = C_PLUS_PLUS;
		else
			this.targetLang = targetLang;

	}

	public void startProcess() {
		try {
			preprocessProtocolBehavior();
			postprocessProtocolBehavior();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void preprocessProtocolBehavior() throws Exception {
		if (_sd != null) {
			String sm = generateSM(_sd);
			FileWriter fw = new FileWriter(jsidlSrcFileName + ".sm");
			fw.write(sm);
			fw.flush();
			fw.close();
		}
	}

	private void postprocessProtocolBehavior() throws Exception {
		// call Smc
		if (targetLang.equals("C_PLUS_PLUS")) {
			String[] args = new String[8];
			/*
			 * boolean retVal = true;
			 * 
			 * File file = new File(targetDest, "src"); if( ! file.exists() )
			 * retVal = file.mkdir(); if( ! retVal ) { throw new
			 * Exception("Error: Unable to create target directory
			 * "+targetDest+"\\src"); }
			 * 
			 * file = new File(targetDest+"\\include"); if( ! file.exists() )
			 * retVal = file.mkdir(); if( ! retVal ) { throw new
			 * Exception("Error: Unable to create target directory
			 * "+targetDest+"\\include"); }
			 */
			args[0] = new String("-c++");
			args[1] = new String("-g");
			args[2] = new String("-return");
			args[3] = new String("-d");
			args[4] = new String(targetDest + "/src/" + dirname);
			args[5] = new String("-headerd");
			args[6] = new String(targetDest + "/include/" + dirname);
			args[7] = new String(jsidlSrcFileName + ".sm");
			Smc.main(args);
			
			modifyPaths();
			includeServiceHeader();
			
			// delete the intermediate .sm file
			new File(jsidlSrcFileName+".sm").delete();
		}
	}
	
	
	// modifies absolute paths to relative paths in generated code
	private void modifyPaths(){
		File file = new File(targetDest + "/src/" + dirname +"/"+jsidlSrcFileName+"_sm.cpp");
		
		if(file.exists())
		{
			try {
			BufferedReader rdr = new BufferedReader( new FileReader(file), 512 );
			StringBuffer strBuf = new StringBuffer();
			String line = null;
						
			while( (line = rdr.readLine()) != null ) {
			   StringTokenizer strTokens = new StringTokenizer(line);
			   
			   // find line with #include containing absolute path
			   if(strTokens.hasMoreElements() && 
					   strTokens.nextToken().equals("#include") &&
					   strTokens.hasMoreElements() &&
					   strTokens.nextToken().contains( new StringBuffer("include"))) {
				 // replace line with #include containing relative path
			     strBuf.append("#include <"+dirname+"/"+jsidlSrcFileName+"_sm.h>\n");
			   }
			   else
				   strBuf.append(line+"\n");
		    }
			rdr.close();
			
			FileWriter fw = new FileWriter(file, false);
			fw.write(strBuf.toString(), 0, strBuf.length());
			fw.close();
			
			} catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}

	private void includeServiceHeader(){
		File file = new File(targetDest + "/include/" + dirname +"/"+jsidlSrcFileName+"_sm.h");
		
		if(file.exists())
		{
			try {
			BufferedReader rdr = new BufferedReader( new FileReader(file), 512 );
			StringBuffer strBuf = new StringBuffer();
			String line = null;
						
			while( (line = rdr.readLine()) != null ) {
			   //StringTokenizer strTokens = new StringTokenizer(line);
			   
			   // adding include line after the #include <statemap.h>
			   if(line.startsWith("#include <statemap.h>")) {
				 // replace line with #include containing relative path
			     strBuf.append(line).append("\n#include <"+dirname +"/"+jsidlSrcFileName+".h>\n");
			     strBuf.append(line).append("\nusing namespace "+CodeGen.ROOT_NAMESPACE+";\n");
			   }
			   else
				   strBuf.append(line+"\n");
		    }
			rdr.close();
			
			FileWriter fw = new FileWriter(file, false);
			fw.write(strBuf.toString(), 0, strBuf.length());
			fw.close();
			
			} catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}

	public String generateSM(ServiceDef _sd) {
		StringBuffer strBuf = new StringBuffer();
        
		ProtocolBehavior _pb = _sd.getProtocolBehavior();

		// add start
		generateStart(_pb.getStart(), strBuf);

		String namespace = ServiceClass.makeNamespace(_sd.getId(), _sd.getVersion());
		if (targetLang.equals("C_PLUS_PLUS")) {
			strBuf.append("%class " + _sd.getName() + "\n");
			strBuf.append("%header <" + namespace+"/"+_sd.getName() + ".h>\n");
			strBuf.append("%include <Message.h>\n");
			strBuf.append("%package " + namespace + "\n");
		}

		Iterator<Map> _iter = _pb.getMap().iterator();

		while (_iter.hasNext()) {
			Map _map = _iter.next();

			strBuf.append("%map " + _map.getName() + "\n");
			strBuf.append("%%\n");
			strBuf.append("// State \t Transition \t End State \t Action(s)\n");
			generateStates(_map, strBuf);
			DefaultState _df = _map.getDefaultState();
			if (_df != null)
				generateDefaultState(_df, strBuf);
			strBuf.append("%%\n");
		}

		return strBuf.toString();
	}

	private static void generateStart(Start _start, StringBuffer strBuf) {
		strBuf.append("%start " + _start.getMap() + "::"
				+ getModifiedName(_start.getState()) + "\n");
	}

	private void generateStates(Map _map, StringBuffer strBuf) {
		Iterator<State> _stateIter = _map.getState().iterator();

		while (_stateIter.hasNext()) {
			State _state = _stateIter.next();

			strBuf.append(getModifiedName(_state.getName())+"\n");
			// strBuf.append(_state.getName()+"\n");

			Entry _entry = _state.getEntry();
			if (_entry != null)
				generateEntry(_entry, strBuf);

			Exit _exit = _state.getExit();
			if (_exit != null)
				generateExit(_exit, strBuf);

			strBuf.append("{\n");

			Iterator<Transition> _transitionIter = _state.getTransition()
					.iterator();
			while (_transitionIter.hasNext()) {
				generateTransition(_transitionIter.next(), strBuf);
			}

			DefaultTransition _dt = _state.getDefaultTransition();
			if (_dt != null)
				generateDefaultTransition(_dt, strBuf);

			strBuf.append("}\n");
		}
	}

	// make state name start with an upper case letter since SMC requires states
	// to start with an upper case letter.
	private static String getModifiedName(String name) {
		String s_letter = name.substring(0, 1);
		return s_letter.toUpperCase() + name.substring(1, name.length());
	}

	private void generateDefaultState(DefaultState _ds, StringBuffer strBuf) {
		strBuf.append("Default\n{\n");
		Iterator<Transition> _iter = _ds.getTransition().iterator();

		while (_iter.hasNext()) {
			generateTransition(_iter.next(), strBuf);
			strBuf.append("\n");
		}
		strBuf.append("}\n");
	}

	private void generateEntry(Entry _entry, StringBuffer strBuf) {
		Iterator<Action> _actionIter = _entry.getAction().iterator();

		strBuf.append("Entry\n{\n");

		while (_actionIter.hasNext()) {
			strBuf.append("\t");
			generateAction(_actionIter.next(), strBuf);
			strBuf.append("\n");
		}

		strBuf.append("}\n");
	}

	private void generateExit(Exit _exit, StringBuffer strBuf) {
		Iterator<Action> _actionIter = _exit.getAction().iterator();

		strBuf.append("Exit\n{\n");

		while (_actionIter.hasNext()) {
			generateAction(_actionIter.next(), strBuf);
		}

		strBuf.append("}\n");
	}

	private void generateTransition(Transition _transition, StringBuffer strBuf) {
		// name
		strBuf.append("\t" + _transition.getName() + "Transition ");
		strBuf.append("( ");

		// parameter
		Iterator<Parameter> paramIter = _transition.getParameter().iterator();

		while (paramIter.hasNext()) {
			generateParameter(paramIter.next(), strBuf);
			if (paramIter.hasNext())
				strBuf.append(", ");
		}
		strBuf.append(" )");

		// guard
		generateGuard(_transition, strBuf);

		// end state
		strBuf.append("\t");
		Simple _simple = _transition.getSimple();
		Push _push = _transition.getPush();
		Pop _pop = _transition.getPop();

		if (_simple != null) {
			generateSimple(_simple, strBuf);
		} else if (_push != null) {
			generatePush(_push, strBuf);
		} else {
			generatePop(_pop, strBuf);
		}

		// actions
		strBuf.append("\t{");
		Iterator<Action> _actionIter = _transition.getAction().iterator();

		while (_actionIter.hasNext()) {
			generateAction(_actionIter.next(), strBuf);
			strBuf.append(" ");
		}
		strBuf.append("}\n");
	}

	private void generateDefaultTransition(DefaultTransition _dt,
			StringBuffer strBuf) {
		strBuf.append("Default");

		// guard
		generateGuard(_dt, strBuf);

		// end state
		strBuf.append("\t");
		Simple _simple = _dt.getSimple();
		Push _push = _dt.getPush();
		Pop _pop = _dt.getPop();

		if (_simple != null) {
			generateSimple(_simple, strBuf);
		} else if (_push != null) {
			generatePush(_push, strBuf);
		} else {
			generatePop(_pop, strBuf);
		}

		// actions
		strBuf.append("\t");
		strBuf.append("{");
		Iterator<Action> _actionIter = _dt.getAction().iterator();

		while (_actionIter.hasNext()) {
			generateAction(_actionIter.next(), strBuf);
			strBuf.append("\n");
		}
		strBuf.append("}");
	}

	// { actionName(arg1, arg2, ...); ... }
	private void generateAction(Action _action, StringBuffer strBuf) {
		strBuf.append(_action.getName() + "Action(");

		Iterator<Argument> _argumentIter = _action.getArgument().iterator();

		while (_argumentIter.hasNext()) {
			generateArgument(_argumentIter.next(), strBuf);

			if (_argumentIter.hasNext())
				strBuf.append(", ");
		}

		strBuf.append(" );");
	}

	private void generateParameter(Parameter _param, StringBuffer strBuf) {
		strBuf.append(_param.getVariable() + ": " + _param.getType()+"*");
	}

	private void generateGuard(Transition _transition, StringBuffer strBuf) {
		Guard _guard = _transition.getGuard();
		if (_guard == null)
			return;
		
		//// get param List
		StringBuffer paramString = new StringBuffer();
		if (_transition.getParameter()!=null && _transition.getParameter().size()>0) {
			for(Parameter pm:_transition.getParameter()) {
				if (paramString.length()>0) paramString.append(", ");
				paramString.append(pm.getType()).append(" ").append(pm.getVariable());
			}
		}
		
		strBuf.append(" [");
		String guard = _guard.getCondition();
		/* need to add ctxt. to functions inside guard */
		if (guard != null) {
			String[] varName = paramString.toString().split(" ");
			strBuf.append(" ctxt." + guard + "(" + varName[varName.length-1] +")");
			// System.out.println(ctxtBuf.toString());
		}
		strBuf.append("]");
	}

	private void generateGuard(DefaultTransition _transition, StringBuffer strBuf) {
		Guard _guard = _transition.getGuard();
		if (_guard == null)
			return;
		
		strBuf.append(" [");
		String guard = _guard.getCondition();
		/* need to add ctxt. to functions inside guard */
		if (guard != null) {
			strBuf.append(" ctxt." + guard + "()");
			// System.out.println(ctxtBuf.toString());
		}
		strBuf.append("]");
	}

	private void generateSimple(Simple _simple, StringBuffer strBuf) {
		generateEndState(_simple.getEndState(), strBuf);
	}

	private void generatePush(Push _push, StringBuffer strBuf) {
		Simple _simple = _push.getSimple();

		if (_simple != null) {
			generateSimple(_simple, strBuf);
			strBuf.append("/");
		}

		strBuf.append("push(");
		generateEndState(_push.getEndState(), strBuf);
		strBuf.append(")");
	}

	private void generatePop(Pop _pop, StringBuffer strBuf) {
		strBuf.append("\tpop");

		String _transitionName = _pop.getTransition();

		if (_transitionName != null) {
			strBuf.append("( " + _transitionName);

			Iterator<Argument> _argumentIter = _pop.getArgument().iterator();

			if (_argumentIter.hasNext())
				strBuf.append(", ");

			while (_argumentIter.hasNext()) {
				generateArgument(_argumentIter.next(), strBuf);

				if (_argumentIter.hasNext())
					strBuf.append(", ");
			}

			strBuf.append(" )");
		}
	}

	private void generateEndState(EndState _endState, StringBuffer strBuf) {
		if (_endState == null)
			strBuf.append("nil");
		else {
			String map = _endState.getMap();
			String state = getModifiedName(_endState.getState());

			if (map != null)
				strBuf.append(map + "::");
			strBuf.append(state);
		}
	}

	private void generateArgument(Argument _arg, StringBuffer strBuf) {

		String arg = _arg.getVariable();

		if (arg != null) {
			strBuf.append(" " + arg);
		} else {
			arg = _arg.getConstant();
			strBuf.append(" \"" + arg + "\"");
		}
	}

	/**
	 * @param argv
	 *            <br>
	 *            argv[0] JSIDL service definition file name (without the .xml
	 *            extension) <br>
	 *            argv[1] target langauge: "C_PLUS_PLUS" or "JAVA"
	 * 
	 */
	// public static void main(String argv[]) {
	// new ProtocolBehaviorClass( argv[0], argv[1], argv[2], argv[3] );
	// }
}
